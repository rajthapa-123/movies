<?php
add_action('wp_enqueue_scripts', 'cinemaxl_add_stylesheet');
function cinemaxl_add_stylesheet()
{
    wp_enqueue_style('cinemaxl-child-style', get_stylesheet_directory_uri() . '/style.css', false, '1.0.0', 'all');
}

<?php

/**
 * Template Name: CinemaXL Table Orders
 *
 *
 */

get_header();
?>

<section class="table-orders" id="table-orders">
    <div class="table-orders__container _container">
        <div class="table-orders__body">
            <?php get_template_part('template-parts/heading', null, array('extra_class' => 'table-orders__heading')); ?>
            <?php if (is_user_logged_in()) : ?>
                <form class="table-orders__form">
                    <div class="table-orders__wrapp">
                        <label for="movie-title"><?php esc_html_e('Title:', 'cinemaxl'); ?></label>
                        <input class="table-orders__input" name="movie_title" type="text" id="movie-title" />
                    </div>

                    <?php
                    $genres = get_terms(array(
                        'taxonomy' => 'genres',
                        'orderby' => 'name',
                        'order' => 'DESC',
                        'parent' => 0,
                        'hide_empty' => false
                    ));
                    ?>
                    <?php if (is_array($genres) && count($genres) > 0) : ?>
                        <div class="table-orders__wrapp">
                            <label for="movie-genre"><?php esc_html_e('Genre:', 'cinemaxl'); ?></label>
                            <select name="movie_genre" id="movie-genre">
                                <?php
                                foreach ($genres as $item) {
                                    printf(
                                        '<option value="%s"/>%s</label>',
                                        esc_attr($item->term_id),
                                        esc_attr($item->name)
                                    );
                                }
                                ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <?php
                    $years = get_terms(array(
                        'taxonomy' => 'years',
                        'orderby' => 'name',
                        'order' => 'DESC',
                        'parent' => 0,
                        'hide_empty' => false
                    ));
                    ?>
                    <?php if (is_array($years) && count($years) > 0) : ?>
                        <div class="table-orders__wrapp">
                            <label for="movie-year"><?php esc_html_e('Year:', 'cinemaxl'); ?></label>
                            <select name="movie_year" id="movie-year">
                                <?php
                                foreach ($years as $item) {
                                    printf(
                                        '<option value="%s"/>%s</label>',
                                        esc_attr($item->term_id),
                                        esc_attr($item->name)
                                    );
                                }
                                ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="table-orders__wrapp">
                        <label for="movie-description"><?php esc_html_e('Description:', 'cinemaxl'); ?></label>
                        <textarea class="table-orders__textarea" name="movie_description" id="movie-description" cols="30" rows="10"></textarea>
                    </div>
                    <button class="table-orders__btn _btn"><?php esc_html_e('Send', 'cinemaxl'); ?></button>
                </form>
            <?php else : ?>
                <?php if (get_the_content()) : ?>
                    <div class="table-orders__salute"><?php the_content(); ?></div>
                <?php endif; ?>
            <?php endif; ?>
            <div class="table-orders__pending pending">
                <table>
                    <thead>
                        <tr>
                            <th>
                                <?php esc_html_e('Name', 'cinemaxl') ?>
                            </th>
                            <th>
                                <?php esc_html_e('Genre', 'cinemaxl') ?>
                            </th>
                            <th>
                                <?php esc_html_e('Customer', 'cinemaxl') ?>
                            </th>
                            <th>
                                <?php esc_html_e('Order Date', 'cinemaxl') ?>
                            </th>
                            <th>
                                <?php esc_html_e('Released', 'cinemaxl') ?>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="pending__tbody">
                        <?php
                        $pending_args = array(
                            'post_type' => 'movies',
                            'posts_per_page' => -1,
                            'post_status' => 'pending',
                        );

                        $pending_movies = new WP_Query($pending_args);

                        if ($pending_movies->have_posts()) : ?>
                            <?php while ($pending_movies->have_posts()) : $pending_movies->the_post(); ?>
                                <tr>
                                    <td>
                                        <?php the_title(); ?>
                                    </td>
                                    <td>
                                        <?php
                                        $terms = get_the_terms(get_the_ID(), 'genres');
                                        $output = array();
                                        foreach ($terms as $term) {
                                            array_push($output, $term->name);
                                        }
                                        echo implode(", ", $output);
                                        ?>
                                    </td>
                                    <td>
                                        <?php the_author(); ?>
                                    </td>
                                    <td>
                                        <?php echo get_the_date('F j, Y'); ?>
                                    </td>
                                    <td>
                                        <?php
                                        $terms = get_the_terms(get_the_ID(), 'years');
                                        $output = array();
                                        foreach ($terms as $term) {
                                            array_push($output, $term->name);
                                        }
                                        echo implode(", ", $output);
                                        ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            <?php wp_reset_postdata(); ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="5">
                                    <?php esc_html_e('No orders', 'cinemaxl') ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();

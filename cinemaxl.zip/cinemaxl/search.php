<?php

get_header();
?>

<section class="custom-page" id="custom-page">
	<div class="custom-page__container _container">
		<div class="custom-page__body">
			<?php get_template_part('template-parts/heading', null, array('extra_class' => 'custom-page__heading')); ?>
			<div class="custom-page__content">
				<?php if (have_posts()) : ?>
					<div class="custom-page__search-results">
						<?php while (have_posts()) : the_post(); ?>
							<?php get_template_part('template-parts/movies', 'filter'); ?>
						<?php endwhile; ?>
					</div>
					<?php custom_paginate_links() ?>
				<?php else : ?>
					<?php get_template_part('template-parts/notfound'); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();

jQuery(document).ready(function ($) {
  "use strict";

  // Preloader
  $("#preloder").delay(1000).fadeOut("slow");

  // WOW Animation When You Scroll
  if ($("*").is(".wow")) {
    var wow = new WOW({
      animateClass: "animate__animated",
      mobile: false,
    });
    wow.init();
  }

  function controlActivation(openNode, closeNode, bodyNode) {
    $(openNode).on("click", function () {
      $(bodyNode).addClass("_active");
      $("body").addClass("_lock");
    });

    $(closeNode).on("click", function () {
      $(bodyNode).removeClass("_active");
      $("body").removeClass("_lock");
    });
  }

  // Search Panel
  controlActivation(
    ".controls__search",
    ".search-panel__close",
    ".header__search-panel"
  );

  $("ul.mobile-menu__list li a > i").on("click", function () {
    $("ul.mobile-menu__list li a > i").toggleClass("_active");
    $("ul.mobile-menu__list li ul.sub-menu").toggleClass("_active");
  });

  // Sub Menu
  $(".controls__burger").on("click", function (e) {
    $(this).toggleClass("_active");
    $(".controls__menu.menu").slideToggle("_active");
  });
  $(document).click(function (e) {
    if (!$(e.target).parents().andSelf().is(".controls__burger")) {
      $(".controls__burger").removeClass("_active");
      $(".controls__menu.menu").slideUp("_active");
    }
  });

  // Movies Slider
  $(".middle__movies-slider").slick({
    slidesToShow: 4,
    arrows: true,
    infinite: false,
    responsive: [
      {
        breakpoint: 1199.98,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 991.98,
        settings: {
          slidesToShow: 2,
          dots: false,
          arrows: true,
        },
      },
      {
        breakpoint: 767.98,
        settings: {
          slidesToShow: 1,
          dots: true,
          arrows: false,
        },
      },
    ],
  });

  // Featured Slider
  $(".featured__slider").slick({
    slidesToShow: 4,
    arrows: true,
    infinite: false,
    responsive: [
      {
        breakpoint: 1199.98,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 991.98,
        settings: {
          slidesToShow: 2,
          dots: false,
          arrows: true,
        },
      },
      {
        breakpoint: 767.98,
        settings: {
          slidesToShow: 1,
          dots: true,
          arrows: false,
        },
      },
    ],
  });

  // Selects
  $(".movies-filters select").each(function (_, item) {
    $(item)
      .select2({
        width: "195px",
        minimumResultsForSearch: -1,
        dropdownParent: $(item).parent(".movies-filters__wrapper"),
        containerCssClass: "select2-container--filters",
        dropdownCssClass: "select2-dropdown--filters",
      })
      .on("select2:open", function (e) {
        $(".select2-dropdown").addClass("animate__animated animate__fadeIn");
      })
      .on("select2:closing", function (e) {
        $(".select2-dropdown").removeClass("animate__animated animate__fadeIn");
      });
  });

  $(".table-orders__form select").each(function (_, item) {
    $(item)
      .select2({
        width: "280px",
        minimumResultsForSearch: -1,
        dropdownParent: $(item).parent(".table-orders__wrapp"),
        containerCssClass: "select2-container--filters",
        dropdownCssClass: "select2-dropdown--filters",
      })
      .on("select2:open", function (e) {
        $(".select2-dropdown").addClass("animate__animated animate__fadeIn");
      })
      .on("select2:closing", function (e) {
        $(".select2-dropdown").removeClass("animate__animated animate__fadeIn");
      });
  });

  // Slowly Scrolling
  $(".go_to").click(function () {
    var elementClick = $(this).attr("href");
    var destination = $(elementClick).offset().top;
    $("body,html").animate({ scrollTop: destination }, 900);
  });

  //Showing Scroll To Up
  $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
      $(".scroll-up").fadeIn();
    } else {
      $(".scroll-up").fadeOut();
    }
  });

  // Tabs
  $(document).on("click", "#tabs__nav", function (e) {
    var buttonIndex = $(e.target).index();
    $("#tabs__nav")
      .children()
      .each(function (_, button) {
        $(button).removeClass("_active");
        $(e.target).addClass("_active");
      });
    $("#tabs__content")
      .children()
      .each(function (contentIndex, content) {
        $(content).removeClass("_active");
        if (buttonIndex == contentIndex) {
          $(content).addClass("_active");
        }
      });
  });
  $("#tabs__nav").children().eq(0).addClass("_active");
  $("#tabs__content").children().eq(0).addClass("_active");

  // Modal Window
  var popupButtons = [];
  var popupWindows = [];

  function openingPopups(buttons, windows, closingBefore) {
    $(buttons).each(function (_, button) {
      $(button).click(function () {
        $(windows).each(function (_, window) {
          if (closingBefore && $(closingBefore).hasClass("_active")) {
            $(closingBefore).removeClass("_active");
          }
          $(window).addClass("_active");
        });
      });
    });
  }

  function closingPopups(windows) {
    $(windows).each(function (_, window) {
      $(window).removeClass("_active");
    });
  }

  openingPopups(popupButtons, popupWindows[0]);

  $(".popup__overlay, .popup__close").click(function () {
    closingPopups(popupWindows);
  });
});

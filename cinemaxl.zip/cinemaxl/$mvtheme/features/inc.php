<?php
/****************************************************************
 * Includes Parts
 ****************************************************************/

/**
 * Init General Features
 */
require_once FEATURES_PATH . '/general.php';

/**
 * Init Breadcrumbs
 */
require_once FEATURES_PATH . '/breadcrumbs.php';

/**
 * Init class Walker_Nav_Menu
 */
require_once FEATURES_PATH . '/custom-menu.php';
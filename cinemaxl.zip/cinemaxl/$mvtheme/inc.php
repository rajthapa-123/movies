<?php

/**
 * Load Theme Variable Data
 * @param string $var
 * @return string 
 */
function mvtheme_theme_data_variable($var)
{
    if (!is_file(STYLESHEETPATH . '/style.css')) {
        return '';
    }

    $theme_data = wp_get_theme();
    return $theme_data->{$var};
}

/****************************************************************
 * Define Constants
 ****************************************************************/
define('CORE_PATH', ROOT_PATH . '/core');
define('CORE_URL', ROOT_URL . '/core');
define('EXTERNAL_PATH', ROOT_PATH . '/external');
define('EXTERNAL_URL', ROOT_URL . '/external');
define('FEATURES_PATH', ROOT_PATH . '/features');
define('FEATURES_URL', ROOT_URL . '/features');
define('MODULES_PATH', ROOT_PATH . '/modules');
define('MODULES_URL', ROOT_URL . '/modules');

define('MVTHEME_THEME_VERSION', mvtheme_theme_data_variable('Version'));
define("MVTHEME_THEME_URL", esc_url(get_template_directory_uri()));
define('MVTHEME_TEXTDOMAIN', 'cinemaxl');

/****************************************************************
 * Require Needed Files & Libraries
 ****************************************************************/
require_once CORE_PATH . '/inc.php';
require_once EXTERNAL_PATH . '/inc.php';
require_once FEATURES_PATH . '/inc.php';
require_once MODULES_PATH . '/inc.php';

/****************************************************************
 * Find The Configuration File
 ****************************************************************/
require_once ROOT_PATH . '/config.php';

if (!isset($content_width)) {
    $content_width = 1240; // default content width
}

load_theme_textdomain(MVTHEME_TEXTDOMAIN, get_template_directory() . '/languages');
$locale = get_locale();
$locale_file = get_template_directory() . "/languages/$locale.php";
if (is_readable($locale_file)) {
    require_once($locale_file);
}

jQuery(document).ready(function ($) {
  "use strict";
  
  $("input[type=file][data-ajaxed=Y]").on("change", function (e) {
    var files = e.target.files,
      cont = $(this).attr("data-cont"),
      name = $(this).attr("name"),
      originPath = $(".profile_image img").attr("src");

    var data = new FormData();

    $.each(files, function (key, value) {
      data.append(key, value);
    });

    data.append("type", $(this).data("type"));

    data.append("action", 'user_profile');

    data.append("nonce", profile.nonce);

    $(cont).html(
      '<img src="' + profile.directoryurl + '/assets/img/preloader.gif" />'
    );

    $.ajax({
      url: profile.ajaxurl, // Url to which the request is send
      type: "POST", // Type of request to be send, called as method
      data: data, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
      dataType: "json",
      contentType: false, // The content type used when sending data to the server.
      cache: false, // To unable request pages to be cached
      processData: false, // To send DOMDocument or non processed data file it is set to false
      success: function (
        data // A function to be called if request succeeds
      ) {
        console.log(data);
        if (data.error) {
          showMessageWindow(0, data.error);
          $(cont).html('<img src="' + originPath + '" />');
        } else {
          $(cont).html(
            '<img src="' +
              data.src +
              '" style="max-width:100%;" alt="avatar" />'
          );
          $("[name=" + name + "_aid]").val(data.aid);
        }
      },
      error: function (jqXHR, textStatus, errorThrown) {
        console.log("ERRORS: " + textStatus);
        showMessageWindow(0, textStatus);
        $(cont).html('<img src="' + originPath + '" />');
      },
    });
  });

  function showMessageWindow(status = 0, message) {
    var title = "";
    switch(status) {
      case 0:
        title = "Error!";
        $(".popup_info .popup_info_title").css("color", "#d10d00");
      break;
      case 1:
        title = "Thanks";
        $(".popup_info .popup_info_title").css("color", "#42e8e0");
      default:
        title = "";
    }

    $(".popup_info .popup_info_title").html(title);
    $(".popup_info .popup_info_text").html(message);
    $(".popup_info").addClass("_active");
  }
});

<?php

class Custom_User_Profile
{
    public function init()
    {
        add_action('wp_enqueue_scripts', array($this, 'custom_user_profile_scripts'));
        // add_action('admin_head', array($this, 'remove_default_profile_fields'));

        // add_action('show_user_profile', array($this, 'add_extra_profile_fields'));
        // add_action('edit_user_profile', array($this, 'add_extra_profile_fields'));

        // add_action('personal_options_update', array($this, 'save_extra_profile_fields'));
        // add_action('edit_user_profile_update', array($this, 'save_extra_profile_fields'));

        add_filter('wp_nav_menu_items',  array($this, 'nav_menu_profile_link'));

        add_action('wp_ajax_user_profile', array($this, 'user_profile_callback'));
        add_action('wp_ajax_nopriv_user_profile', array($this, 'user_profile_callback'));
    }

    public function custom_user_profile_scripts()
    {
        if (is_page(mvt_get_option('profile_page_slug'))) {
            // Register the styles
            wp_register_style('custom-user-profile-style', MODULES_URL . '/custom-user-profile/css/styles.css');
            // Register the script
            wp_register_script('custom-user-profile-script', MODULES_URL . '/custom-user-profile/js/scripts.js', array('jquery'));

            // Localize the script with new data
            $script_data_array = array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'directoryurl' => get_template_directory_uri(),
                'nonce' => wp_create_nonce('custom-user-profile-nonce'),
            );
            wp_localize_script('custom-user-profile-script', 'profile', $script_data_array);

            // Enqueued script with localized data.
            wp_enqueue_script('custom-user-profile-script');
            // Enqueued styles.
            wp_enqueue_style('custom-user-profile-style');
        }
    }

    function nav_menu_profile_link($menu)
    {
        if (!is_user_logged_in()) {
            return $menu;
        } else {
            $profilelink = '<li><a href="' . home_url('profile') . '">' . __('Profile', 'cinemaxl') . '</a></li>';
            $menu_list = $menu . $profilelink;
            return $menu_list;
        }
    }

    public function remove_default_profile_fields()
    {
        global $pagenow;

        if ('user-profile.php' != $pagenow) return;

        remove_action('admin_color_scheme_picker', 'admin_color_scheme_picker');

        // <tr> selectors, each containing a field
        $tr = array(
            "tr.user-profile-picture",
        );

        $selectors = implode(", ", $tr);

        // Hide the fields with css, so even if javascript is disabled they wont show up. 
        echo "<style>{$selectors}{display:none;}</style>"; ?>

        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Hide selected <tr>'s
                $('<?php $selectors; ?>').hide();
                // Hide any empty table that may have been left over
                $(".form-table:not(:has(tr))").hide();
            });
        </script>

    <?php
    }

    public function add_extra_profile_fields($user)
    {
    ?>
        <table class="form-table">
            <tr>
                <th><label for="test"><?php esc_html_e('Test', 'cinemaxl') ?></label></th>
                <td>
                    <input type="text" name="test" id="test" value="<?php echo esc_html(get_the_author_meta('test', $user->ID)); ?>" />
                </td>
            </tr>
        </table>
    <?php
    }

    public function save_extra_profile_fields($user_id)
    {
        update_user_meta($user_id, 'test', sanitize_text_field($_POST['test']));
    }

    public function user_profile_callback()
    {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'custom-user-profile-nonce')) {
            exit;
        }

        //Get the file
        $f = 0;
        $_FILES[$f] = $_FILES[0];

        $extensions = array('jpg', 'png', 'gif');
        //a list of extensions that we allo to be uploaded
        $file_ext = explode('.', $_FILES[$f]['name']);
        $file_ext = end($file_ext);
        $ext_error = false;
        if (!in_array($file_ext, $extensions)) {
            $ext_error = true;
        }

        $user = new WP_User(get_current_user_id());

        $json = ["error" => ""];

        //Check if the file is available && the user is logged in
        if (!empty($_FILES[$f]) && !empty($_FILES[$f]['name']) && $user->ID > 0) {

            //If error
            if ($_FILES[$f]['size'] > 2097152) {
                $json['error'] = __("The file is too large (<=2M)", "cinemaxl");
            } else if ($ext_error) {
                $json['error'] = __("File not allowed. (jpg, png, gif)", "cinemaxl");
            } else {
                $json['error'] = "";
            }

            if ($json['error'] === "") {

                require_once(ABSPATH . 'wp-admin/includes/image.php');
                require_once(ABSPATH . 'wp-admin/includes/file.php');
                require_once(ABSPATH . 'wp-admin/includes/media.php');

                //Handle the media upload using WordPress helper functions
                $attachment_id = media_handle_upload($f, 0);
                $json['aid']   = $attachment_id;

                if (is_wp_error($attachment_id)) {
                    $json['error'] = __("Attachment ID missing", "cinemaxl");
                } else {
                    //delete current
                    $profile_image = get_user_meta($user->ID, 'profile_image', true);
                    if ($profile_image) {
                        $profile_image = json_decode($profile_image);
                        if (isset($profile_image->attachment_id)) {
                            wp_delete_attachment($profile_image->attachment_id, true);
                        }
                    }

                    //Generate attachment in the media library
                    $attachment_file_path = get_attached_file($attachment_id);
                    $data                 = wp_generate_attachment_metadata($attachment_id, $attachment_file_path);

                    //Get the attachment entry in media library
                    $image_full_attributes  = wp_get_attachment_image_src($attachment_id, 'full');
                    $image_thumb_attributes = wp_get_attachment_image_src($attachment_id, 'smallthumb');

                    $arr = array(
                        'attachment_id' => $attachment_id,
                        'url' => $image_full_attributes[0],
                        'thumb' => $image_thumb_attributes[0]
                    );

                    //Save the image in the user metadata
                    update_user_meta($user->ID, 'profile_image', json_encode($arr, JSON_PRETTY_PRINT));

                    $json['src']    = $arr['thumb'];
                    $json['status'] = 'ok';
                }
            }
        } else {
            $json['error'] = __("File not selected or empty or other problem.", "cinemaxl");
        }
        //Output the json
        die(json_encode($json));
    }
}

if (class_exists("Custom_User_Profile")) {
    $custom_user_profile = new Custom_User_Profile();
    $custom_user_profile->init();
}

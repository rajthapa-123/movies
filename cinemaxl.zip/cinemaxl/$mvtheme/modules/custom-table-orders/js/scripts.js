jQuery(document).ready(function ($) {
  "use strict";
  
  $(document).on("click", ".table-orders__btn", function (e) {
    e.preventDefault();

    var movieTitleInput = $(".table-orders__form input[name=movie_title]");

    if (movieTitleInput.val() !== "") {
      if (movieTitleInput.hasClass("_error")) {
        movieTitleInput.removeClass("_error");
      }
      fetchOrder();
    } else {
      movieTitleInput.addClass("_error");
    }
  });

  function fetchOrder() {
    $.ajax({
      url: orders.ajaxurl,
      type: "POST",
      data: {
        action: "table_orders",
        form_data: $(".table-orders__form").serialize(),
        nonce: orders.nonce,
      },
      beforeSend: function () {
        $(".table-orders__pending tbody").addClass("_loading");
      },
      success: function (response) {
        $(".table-orders__pending tbody").removeClass("_loading");
        $(".table-orders__pending tbody").html(response.data);
      },
    });
  }
});

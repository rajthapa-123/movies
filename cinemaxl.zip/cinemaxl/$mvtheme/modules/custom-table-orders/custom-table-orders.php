<?php

function custom_table_orders_scripts()
{
    if (is_page('table-orders')) {
        // Register the script
        wp_register_script('custom-table-orders-script', MODULES_URL . '/custom-table-orders/js/scripts.js', array('jquery'));

        // Localize the script with new data
        $script_data_array = array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('custom-table-orders-nonce'),
        );
        wp_localize_script('custom-table-orders-script', 'orders', $script_data_array);

        // Enqueued script with localized data.
        wp_enqueue_script('custom-table-orders-script');
    }
}
add_action('wp_enqueue_scripts', 'custom_table_orders_scripts');

function table_orders_callback()
{
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'custom-table-orders-nonce')) {
        exit;
    }

    $params = array();
    parse_str($_POST['form_data'], $params);

    /*
    movie_description
    movie_genre
    movie_title
    movie_year
    */

    $new_post = array(
        'post_title' => wp_strip_all_tags($params['movie_title']),
        'post_content' => $params['movie_description'],
        'post_status' => 'pending',
        'post_type' => 'movies',
    );

    $post_id = wp_insert_post($new_post);
    wp_set_object_terms($post_id, intval($params['movie_genre']), 'genres');
    wp_set_object_terms($post_id, intval($params['movie_year']), 'years');


    $pending_args = array(
        'post_type' => 'movies',
        'posts_per_page' => -1,
        'post_status' => 'pending',
    );

    $pending_movies = new WP_Query($pending_args);
    ob_start();
    if ($pending_movies->have_posts()) : ?>
        <?php while ($pending_movies->have_posts()) : $pending_movies->the_post(); ?>
            <tr>
                <td>
                    <?php the_title(); ?>
                </td>
                <td>
                    <?php
                    $terms = get_the_terms(get_the_ID(), 'genres');
                    $output = array();
                    foreach ($terms as $term) {
                        array_push($output, $term->name);
                    }
                    echo implode(", ", $output);
                    ?>
                </td>
                <td>
                    <?php the_author(); ?>
                </td>
                <td>
                    <?php echo get_the_date('d.m.Y'); ?>
                </td>
                <td>
                    <?php
                    $terms = get_the_terms(get_the_ID(), 'years');
                    $output = array();
                    foreach ($terms as $term) {
                        array_push($output, $term->name);
                    }
                    echo implode(", ", $output);
                    ?>
                </td>
            </tr>
        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
    <?php endif; ?>
    <?php
    $data = ob_get_clean();
    wp_send_json_success($data);
    wp_die();
}
add_action('wp_ajax_table_orders', 'table_orders_callback');
add_action('wp_ajax_nopriv_table_orders', 'table_orders_callback');

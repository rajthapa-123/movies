<?php

/**
 * Enqueue scripts and styles for Admin.
 */
function custom_metaboxes_add_scripts($hook)
{
	if ('post-new.php' == $hook || 'post.php' == $hook) {
		wp_enqueue_style('custom-metaboxes-styles', MODULES_URL . '/custom-metaboxes/css/styles.css', array(), '', false);
		wp_enqueue_style('font-awesome',  MODULES_URL . '/custom-metaboxes/css/font-awesome.min.css', array(), '', false);

		wp_enqueue_script('custom-metaboxes-scripts', MODULES_URL . '/custom-metaboxes/js/scripts.js', array('jquery', 'jquery-ui-core', 'jquery-ui-sortable', 'jquery-ui-datepicker', 'media-upload', 'thickbox'));
		wp_enqueue_script('custom-metaboxes-colorpicker', MODULES_URL  . '/custom-metaboxes/js/custom-metaboxes-colorpicker.js', array('jquery'));
		wp_enqueue_script('custom-metaboxes-gallery', MODULES_URL  . '/custom-metaboxes/js/custom-metaboxes-gallery.js', array('jquery'));
	}
}
add_action('admin_enqueue_scripts', 'custom_metaboxes_add_scripts', 10);

require_once MODULES_PATH . '/custom-metaboxes/includes/metabox-fields.php';
require_once MODULES_PATH . '/custom-metaboxes/includes/metabox-gallery.php';

<?php
class Custom_Post_Filters
{
    public function init()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_post_filters', array($this, 'post_filters_handler')); // wp_ajax_{action}
        add_action('wp_ajax_nopriv_post_filters', array($this, 'post_filters_handler')); // wp_ajax_nopriv_{action}
    }

    function enqueue_scripts()
    {
        if (is_front_page()) {
            // register our main script but do not enqueue it yet
            wp_register_script('custom_post_filters_script', MODULES_URL . '/custom-post-filters/js/scripts.js', array('jquery'));

            // now the most interesting part
            // we have to pass parameters to scripts.js script but we can get the parameters values only in PHP
            // you can define variables directly in your HTML but I decided that the most proper way is wp_localize_script()
            wp_localize_script('custom_post_filters_script', 'movies_params', array(
                'ajaxurl' => site_url() . '/wp-admin/admin-ajax.php', // WordPress AJAX
                'nonce' => wp_create_nonce('custom-post-filters-nonce'),
            ));

            wp_enqueue_script('custom_post_filters_script');
        }
    }

    function post_filters_handler()
    {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'custom-post-filters-nonce')) {
            exit;
        }

        $params = array();
        parse_str($_POST['form_data'], $params);

        $paged = !empty($params['paged']) ? (int) $params['paged'] : 1;

        $genres_id = $params['genres_id'];
        $quality_id = $params['quality_id'];
        $years_id = $params['years_id'];
        $ordering = !empty($params['ordering']) ? $params['ordering'] : 'date';

        $tax_query = array();

        if (!empty($genres_id) && $genres_id) {
            array_push(
                $tax_query,
                array(
                    'taxonomy' => 'genres',
                    'field'    => 'id',
                    'terms'    => $genres_id,
                )
            );
        }

        if (!empty($quality_id) && $quality_id) {
            array_push(
                $tax_query,
                array(
                    'taxonomy' => 'quality',
                    'field'    => 'id',
                    'terms'    => $quality_id,
                )
            );
        }

        if (!empty($years_id) && $years_id) {
            array_push(
                $tax_query,
                array(
                    'taxonomy' => 'years',
                    'field'    => 'id',
                    'terms'    => $years_id,
                )
            );
        }

        $args = array(
            'post_type'        => 'movies',
            'posts_per_page'   => get_option('posts_per_page'),
            'post_status'      => 'publish',
            'paged'            => $paged,
            'tax_query'        => $tax_query,
        );

        switch ($ordering) {
            case 'date':
                $args['orderby'] = 'date';
                $args['order'] = 'desc';
                break;
            case 'popularity':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = 'total_sales';
                $args['order'] = 'desc';
                break;
            case 'comment-count':
                $args['orderby'] = 'comment_count';
                $args['order'] = 'asc';
                break;
            case 'comment-count-desc':
                $args['orderby'] = 'comment_count';
                $args['order'] = 'desc';
                break;
            case 'rating-imdb':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = 'mvtheme_movies_rating_imdb';
                $args['order'] = 'asc';
                break;
            case 'rating-imdb-desc':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = 'mvtheme_movies_rating_imdb';
                $args['order'] = 'desc';
                break;
        }

        $loop = new WP_Query($args);

        $max_pages = $loop->max_num_pages;

        ob_start();
        $loop = new WP_Query($args);
        if ($loop->have_posts()) :
            while ($loop->have_posts()) :
                $loop->the_post();
                get_template_part('template-parts/movies', 'filter');

            endwhile;

            echo '<nav class="pagination _ajax">';
            if ($max_pages > 1) {

                $big = 999999999; // need an unlikely integer

                echo paginate_links(array(
                    'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format' => '?paged=%#%',
                    'prev_text' => '<i class="icon-arrow-left-pg"></i>',
                    'next_text' => '<i class="icon-arrow-right-pg"></i>',
                    'current' => max(1, $paged),
                    'total' => $max_pages
                ));
            }
            echo '</nav>';

        else :
            echo '<p class="paragraph-null">' . esc_html('Nothing found for your request.', MVTHEME_TEXTDOMAIN) . '</p>';
        endif;
        wp_reset_postdata();
        $data = ob_get_clean();

        $result = [
            'max' => $max_pages,
            'html' => $data,
        ];

        wp_send_json_success($result);
        wp_die();
    }
}

if (class_exists('Custom_Post_Filters')) {
    $filters = new Custom_Post_Filters();
    $filters->init();
}

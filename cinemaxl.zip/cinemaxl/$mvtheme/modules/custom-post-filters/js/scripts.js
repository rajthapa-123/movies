jQuery(document).ready(function ($) {
  "use strict";

  var getUrlParams = function (url) {
    var params = {};
    (url + "?")
      .split("?")[1]
      .split("&")
      .forEach(function (pair) {
        pair = (pair + "=").split("=").map(decodeURIComponent);
        if (pair[0].length) {
          params[pair[0]] = pair[1];
        }
      });
    return params;
  };

  var getParams = getUrlParams(window.location.href);

  if (Object.keys(getParams).length > 0) {
    loadingMovies("", window.location.search.slice(1));
  }

  $(document).on("click", ".pagination._ajax a", function (e) {
    e.preventDefault();
    var url = $(this).attr("href");
    var paged = "";

    if (url.indexOf("paged=") !== -1) {
      paged = url.split("paged=")[1];
    } else {
      paged = url.split("/page/")[1].replace("/", "");
    }
    loadingMovies(paged);
    setTimeout(function () {
      $("html, body").animate(
        { scrollTop: $(".middle__movies-filters").offset().top },
        900
      );
    }, 500);
  });

  $(document).on("click", ".movies-filters__btn", function (e) {
    e.preventDefault();
    $(".movies__list").html("");
    loadingMovies(1);
  });

  function loadingMovies(paged, data = $(".movies-filters").serialize()) {
    $.ajax({
      url: movies_params.ajaxurl,
      type: "POST",
      data: {
        action: "post_filters",
        nonce: movies_params.nonce,
        form_data: data + (paged !== "" ? "&paged=" + paged : ""),
      },
      beforeSend: function () {
        $(".movies__list").addClass("_loading");
      },
      success: function (response) {
        window.history.pushState(
          "",
          "title",
          "?" + data + (paged !== "" ? "&paged=" + paged : "")
        );
        $(".movies__list").removeClass("_loading");
        $(".movies__list").html(response.data.html);
      },
    });
  }

  $(".movies-filters__wrapper select").each(function (_, item) {
    $.each(getParams, function (key, value) {
      if(key === $(item).attr("name")) {
        $(item).val(value).trigger('change');
      }
    });
  });
});

<?php
/****************************************************************
 * Includes Parts
 ****************************************************************/

/**
 * Init Options Framework
 */
require_once MODULES_PATH . '/options-framework/options-framework.php';

/**
 * Init Custom Metaboxes.
 */
require_once MODULES_PATH . '/custom-metaboxes/custom-metaboxes.php';

/**
 * Init Taxonomy Metaboxes.
 */
require_once MODULES_PATH . '/taxonomies/tax-meta-class.php';

/**
 * Init Custom Ajax Auth Module
 */
require_once MODULES_PATH . '/custom-ajax-auth/custom-ajax-auth.php';

/**
 * Init Custom Post Filters Module
 */
require_once MODULES_PATH . '/custom-post-filters/custom-post-filters.php';

/**
 * Init Core For Profile Page //*Avatar*\\
 */
require_once MODULES_PATH . '/custom-user-profile/custom-user-profile.php';

/**
 * Init Core For Table Orders Page
 */
require_once MODULES_PATH . '/custom-table-orders/custom-table-orders.php';
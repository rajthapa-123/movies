<?php

class Custom_Ajax_Auth
{
    public $redirect_url;

    public function __construct($redirect_url)
    {
        $this->redirect_url = $redirect_url;

        add_action('init', array($this, 'ajax_auth_init'));
        add_action('wp_footer', array($this, 'ajax_get_forms_templates'), 1);

        // Enable the user with no privileges to run ajax_login() in AJAX
        add_action('wp_ajax_nopriv_ajaxlogin', array($this, 'ajax_login'));
        // Enable the user with no privileges to run ajax_register() in AJAX
        add_action('wp_ajax_nopriv_ajaxregister', array($this, 'ajax_register'));
        // Enable the user with no privileges to run ajax_forgotPassword() in AJAX
        add_action('wp_ajax_nopriv_ajaxforgotpassword', array($this, 'ajax_forgotPassword'));
    }

    public function ajax_auth_init()
    {
        wp_register_style('custom-ajax-auth-style', MODULES_URL . '/custom-ajax-auth/css/styles.css');
        wp_enqueue_style('custom-ajax-auth-style');

        wp_register_script('validate-script', MODULES_URL . '/custom-ajax-auth/js/jquery.validate.min.js', array('jquery'));
        wp_enqueue_script('validate-script');

        wp_register_script('custom-ajax-auth-script', MODULES_URL . '/custom-ajax-auth/js/scripts.js', array('jquery'));
        wp_enqueue_script('custom-ajax-auth-script');

        wp_localize_script('custom-ajax-auth-script', 'ajax_auth_object', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'redirecturl' => $this->redirect_url,
            'loadingmessage' => esc_html__('Sending user info, please wait...', 'cinemaxl')
        ));
    }

    public function ajax_get_forms_templates()
    {
        require_once MODULES_PATH . '/custom-ajax-auth/templates/template-login.php';
        require_once MODULES_PATH . '/custom-ajax-auth/templates/template-register.php';
        require_once MODULES_PATH . '/custom-ajax-auth/templates/template-forgot-password.php';
    }

    public function ajax_login()
    {
        // First check the nonce, if it fails the function will break
        check_ajax_referer('ajax-login-nonce', 'security');

        // Nonce is checked, get the POST data and sign user on
        // Call auth_user_login
        $this->auth_user_login($_POST['username'], $_POST['password'], esc_html__('Login', 'cinemaxl'));

        die();
    }

    public function ajax_register()
    {
        // First check the nonce, if it fails the function will break
        check_ajax_referer('ajax-register-nonce', 'security');

        // Nonce is checked, get the POST data and sign user on
        $info = array();
        $info['user_nicename'] = $info['nickname'] = $info['display_name'] = $info['first_name'] = $info['user_login'] = sanitize_user($_POST['username']);
        $info['user_pass'] = sanitize_text_field($_POST['password']);
        $info['user_email'] = sanitize_email($_POST['email']);

        // Register the user
        $user_register = wp_insert_user($info);
        if (is_wp_error($user_register)) {
            $error  = $user_register->get_error_codes();

            if (in_array('empty_user_login', $error)) {
                echo json_encode(array('loggedin' => false, 'message' => $user_register->get_error_message('empty_user_login')));
            } else if (in_array('existing_user_login', $error)) {
                echo json_encode(array('loggedin' => false, 'message' => esc_html__('This username is already registered.', 'cinemaxl')));
            } else if (in_array('existing_user_email', $error)) {
                echo json_encode(array('loggedin' => false, 'message' => esc_html__('This email address is already registered.', 'cinemaxl')));
            }
        } else {
            $this->auth_user_login($info['nickname'], $info['user_pass'], esc_html__('Registration', 'cinemaxl'));
        }

        die();
    }

    public function ajax_forgotPassword()
    {
        // First check the nonce, if it fails the function will break
        check_ajax_referer('ajax-forgot-nonce', 'security');

        global $wpdb;

        $account = $_POST['username'];

        if (empty($account)) {
            $error = esc_html__('Enter an username or e-mail address.', 'cinemaxl');
        } else {
            if (is_email($account)) {
                if (email_exists($account))
                    $get_by = 'email';
                else
                    $error = esc_html__('There is no user registered with that email address.', 'cinemaxl');
            } else if (validate_username($account)) {
                if (username_exists($account))
                    $get_by = 'login';
                else
                    $error = esc_html__('There is no user registered with that username.', 'cinemaxl');
            } else
                $error = esc_html__('Invalid username or e-mail address.', 'cinemaxl');
        }

        if (empty($error)) {
            // lets generate our new password
            // $random_password = wp_generate_password( 12, false );
            $random_password = wp_generate_password();


            // Get user data by field and data, fields are id, slug, email and login
            $user = get_user_by($get_by, $account);

            $update_user = wp_update_user(array('ID' => $user->ID, 'user_pass' => $random_password));

            // if update user return true then lets send user an email containing the new password
            if ($update_user) {

                $from = 'WRITE SENDER EMAIL ADDRESS HERE'; // Set whatever you want like mail@yourdomain.com

                if (!(isset($from) && is_email($from))) {
                    $sitename = strtolower($_SERVER['SERVER_NAME']);
                    if (substr($sitename, 0, 4) == 'www.') {
                        $sitename = substr($sitename, 4);
                    }
                    $from = get_option('admin_email');
                }

                $to = $user->user_email;
                $subject = esc_html__('Your new password', 'cinemaxl');
                $sender = esc_html__('From: ', 'cinemaxl') . get_option('name') . ' <' . $from . '>' . "\r\n";

                $message = esc_html__('Your new password is: ', 'cinemaxl') . $random_password;

                $headers[] = 'MIME-Version: 1.0' . "\r\n";
                $headers[] = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                $headers[] = "X-Mailer: PHP \r\n";
                $headers[] = $sender;

                $mail = wp_mail($to, $subject, $message, $headers);
                if ($mail)
                    $success = esc_html__('Check your email address for you new password.', 'cinemaxl');
                else
                    $error = esc_html__('System is unable to send you mail containg your new password.', 'cinemaxl');
            } else {
                $error = esc_html__('Oops! Something went wrong while updaing your account.', 'cinemaxl');
            }
        }

        if (!empty($error))
            echo json_encode(array('loggedin' => false, 'message' => __($error)));

        if (!empty($success))
            echo json_encode(array('loggedin' => false, 'message' => __($success)));

        die();
    }

    private function auth_user_login($user_login, $password, $login)
    {
        $info = array();
        $info['user_login'] = $user_login;
        $info['user_password'] = $password;
        $info['remember'] = true;

        $user_signon = wp_signon($info, '');
        if (is_wp_error($user_signon)) {
            echo json_encode(array('loggedin' => false, 'message' => esc_html__('Wrong username or password.', 'cinemaxl')));
        } else {
            wp_set_current_user($user_signon->ID);
            echo json_encode(array('loggedin' => true, 'message' => $login . esc_html__(' successful, redirecting...', 'cinemaxl')));
        }

        die();
    }
}


if (class_exists('Custom_Ajax_Auth')) {
    new Custom_Ajax_Auth(home_url('profile'), 'cinemaxl');
}

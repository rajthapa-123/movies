<!-- MODAL WINDOW FOR LOGIN" -->
<form id="login" class="ajax-auth" action="login" method="post">
	<div class="ajax-auth__body">
		<div class="ajax-auth__close"></div>
		<div class="ajax-auth__header login__header">
			<h3 class="ajax-auth__title login__title"><?php esc_html_e('Sign In', 'cinemaxl'); ?></h3>
			<p class="status"></p>
			<?php wp_nonce_field('ajax-login-nonce', 'security'); ?>
		</div>
		<div class="ajax-auth__wrapper login__wrapper">
			<input type="text" id="username" class="ajax-auth__input login__input required" placeholder="user@example.com" name="username" autocomplete="off" />
		</div>
		<div class="ajax-auth__wrapper login__wrapper">
			<input type="password" id="password" class="ajax-auth__input login__input required" placeholder="Password" name="password" autocomplete="off" />
		</div>
		<a href="#" id="pop_forgot" class="ajax-auth__forgot login__forgot">
			<?php esc_html_e('Forgot your password?', 'cinemaxl'); ?>
		</a>
		<button type="submit" class="ajax-auth__btn login__btn _btn"><?php esc_html_e('Sign in', 'cinemaxl'); ?></button>
		<div class="ajax-auth__bottom login__bottom">
			<p class="ajax-auth__left login__left"><?php esc_html_e('Don\'t have an account?', 'cinemaxl'); ?></p>
			<a href="#" id="pop_signup" class="ajax-auth__right login__right"><?php esc_html_e('Sign Up!', 'cinemaxl'); ?></a>
		</div>
	</div>
</form>
<!-- END MODAL WINDOW -->
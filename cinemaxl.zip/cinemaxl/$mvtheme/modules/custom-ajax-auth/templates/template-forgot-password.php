<!-- MODAL WINDOW FOR FORGOT PASSWORD -->
<form id="forgot_password" class="ajax-auth" action="forgot_password" method="post">
	<div class="ajax-auth__body">
		<div class="ajax-auth__close"></div>
		<div class="ajax-auth__header forgot__header">
			<h3 class="ajax-auth__title forgot__title"><?php esc_html_e('Forgot Password', 'cinemaxl') ?></h3>
			<p class="status"></p>
			<?php wp_nonce_field('ajax-forgot-nonce', 'forgotsecurity'); ?>
		</div>
		<div class="ajax-auth__wrapper forgot__wrapper">
			<input type="text" id="recoveryname" class="ajax-auth__input forgot__input required" placeholder="Username" name="recoveryname" autocomplete="off" />
		</div>
		<button type="submit" class="ajax-auth__btn forgot__btn _btn"><?php esc_html_e('Submit', 'cinemaxl'); ?></button>
	</div>
</form>
<!-- END MODAL WINDOW -->
<!-- MODAL WINDOW FOR REGISTER" -->
<form id="register" class="ajax-auth" action="register" method="post">
    <div class="ajax-auth__body">
        <div class="ajax-auth__close"></div>
        <div class="ajax-auth__header register__header">
            <h3 class="ajax-auth__title register__title"><?php esc_html_e('Sign Up', 'cinemaxl'); ?></h3>
            <p class="status"></p>
            <?php wp_nonce_field('ajax-register-nonce', 'signonsecurity'); ?>
        </div>
        <div class="ajax-auth__wrapper register__wrapper">
            <input type="text" id="signonname" class="ajax-auth__input register__input required" placeholder="Username" name="signonname" autocomplete="off" />
        </div>
        <div class="ajax-auth__wrapper register__wrapper">
            <input type="text" id="email" class="ajax-auth__input register__input required" placeholder="user@example.com" name="email" autocomplete="off" />
        </div>
        <div class="ajax-auth__wrapper register__wrapper">
            <input type="password" id="signonpassword" class="ajax-auth__input register__input required" placeholder="Password" name="signonpassword" autocomplete="off" />
        </div>
        <div class="ajax-auth__wrapper register__wrapper">
            <input type="password" id="password2" class="ajax-auth__input register__input required" placeholder="Confirm Password" name="password2" autocomplete="off" />
        </div>
        <button type="submit" class="ajax-auth__btn register__btn _btn"><?php esc_html_e('Register', 'cinemaxl'); ?></button>
        <div class="ajax-auth__bottom register__bottom">
            <p class="ajax-auth__left register__left">
                <?php esc_html_e('Don\'t have an account?', 'cinemaxl'); ?>
            </p>
            <a href="#" id="pop_login" class="ajax-auth__right register__right">
                <?php esc_html_e('Sign In!', 'cinemaxl'); ?>
            </a>
        </div>
    </div>
</form>
<!-- END MODAL WINDOW -->
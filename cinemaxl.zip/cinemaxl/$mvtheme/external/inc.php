<?php
/****************************************************************
 * Includes Parts
 ****************************************************************/

/**
 * TGM Plugin Activation.
 */
require_once EXTERNAL_PATH . '/tgm/class-tgm-plugin-activation.php';
require_once EXTERNAL_PATH . '/tgm/tgm-settings.php';

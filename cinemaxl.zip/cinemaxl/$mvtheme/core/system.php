<?php

// THIS INCLUDES THE THUMBNAIL IN OUR RSS FEED
function mvt_insert_feed_image($content)
{
    global $post;

    if (has_post_thumbnail($post->ID)) {
        $content = ' ' . get_the_post_thumbnail($post->ID, 'medium') . " " . $content;
    }
    return $content;
}

add_filter('the_excerpt_rss', 'mvt_insert_feed_image');
add_filter('the_content_rss', 'mvt_insert_feed_image');


/**
 * Add custom image size wrapper
 * @param string $post_type
 * @param array $config 
 */
function mvt_add_image_size($post_type, $config)
{
    add_image_size($config['name'], $config['width'], $config['height'], $config['crop']);
}


/**
 * Initialize Theme Support Features 
 */
function mvt_init_theme_support()
{
    if (function_exists('mvt_get_images_sizes')) {
        foreach (mvt_get_images_sizes() as $post_type => $sizes) {
            foreach ($sizes as $config) {
                mvt_add_image_size($post_type, $config);
            }
        }
    }
}
add_action('init', 'mvt_init_theme_support');

function mvt_after_setup_theme()
{
    // add editor style for admin editor
    add_editor_style();

    // add post thumbnails support
    add_theme_support('post-thumbnails');

    // add needed post formats to theme
    if (function_exists('mvt_get_post_formats')) {
        add_theme_support('post-formats', mvt_get_post_formats());
    }
}
add_action('after_setup_theme', 'mvt_after_setup_theme');

/**
 * Initialize Theme Navigation 
 */
function mvt_init_navigation()
{
    if (function_exists('register_nav_menus')) {

        register_nav_menus(array(
            'header_menu'    => esc_html__('Header Menu', 'cinemaxl'),
            'footer_menu'    => esc_html__('Footer Menu', 'cinemaxl'),
        ));
    }
}
add_action('init', 'mvt_init_navigation');

function mvt_archive_menu_filter($items, $menu, $args)
{
    foreach ($items as &$item) {
        if ($item->object != 'mvt-archive')
            continue;
        $item->url = get_post_type_archive_link($item->type);

        /* set current */
        if (get_query_var('post_type') == $item->type) {
            $item->classes[] = 'current-menu-item';
            $item->current = true;
        }
    }

    return $items;
}
add_filter('wp_get_nav_menu_items', 'mvt_archive_menu_filter', 10, 3);

/**
 * 
 * Add featured image column to WP admin panel - posts AND pages
 */

function add_image_columns_in_post_types($column_title, $post_types)
{
    if (!is_array($post_types)) {
        return;
    }

    foreach ($post_types as $post_type) {
        add_filter('manage_' . $post_type . '_posts_columns', function ($columns) use ($column_title) {
            $columns['custom_' . sanitize_title($column_title)] = $column_title;
            return $columns;
        }, 2);
        add_action('manage_' . $post_type . '_posts_custom_column', function ($column_name, $post_id) use ($column_title) {
            if ($column_name === 'custom_' . sanitize_title($column_title)) {
                if (get_the_post_thumbnail($post_id)) {
                    echo get_the_post_thumbnail($post_id, array(100, 138));
                } else {
                    echo '<img src="' . ROOT_URL . '/assets/img/100x138.png" alt="placeholder" />';
                }
            }
        }, 5, 2);

        // Move the new column at the first place.
        add_filter('manage_' . $post_type . '_posts_columns', function ($columns) use ($column_title) {
            $new_columns = array();
            $move = 'custom_' . sanitize_title($column_title); // which column to move
            $before = 'title'; // move before this column

            foreach ($columns as $key => $value) {
                if ($key == $before) {
                    $new_columns[$move] = $move;
                }
                $new_columns[$key] = $value;
            }
            return $new_columns;
        });
    }

    // Set columns width
    function add_inline_styles()
    {
        echo '
            <style type="text/css">
                .edit-php .fixed td[class*="column-custom_"],
                .edit-php .fixed th[class*="column-custom_"] {
                    width: 100px;
                }
            </style>
        ';
    }
    add_action('admin_enqueue_scripts', 'add_inline_styles');
}

<?php

/**
 * Inline Styles
 */
function mvt_css_inline_styles()
{
    $color = mvt_get_option('main_color') !== "" ? mvt_get_option('main_color') : '#009688';
    $rgba = convert_hexToRgb($color, '0.6');

    $styles = "
    ._btn, .comments-area .comment-respond .comment-form .form-submit input[type=submit],
    input[type=submit],
    .slick-dots li.slick-active button::after,
    .headline .headline__delimiter span,
    .custom-page:not(._shop) .custom-page__content > ul li::before,
    .article__content > ul li::before,
    .custom-page:not(._shop) .custom-page__content a::before,
    .article__content a::before,
    .header .header__body .header__controls.controls .controls__burger span,
    .header .header__body .header__controls.controls .controls__burger span::after,
    .header .header__body .header__controls.controls .controls__burger span::before,
    .movie-details .movie-details__body .movie-details__article.article .article__wrapper .article__player.player .mejs-container .mejs-inner .mejs-controls .mejs-time-rail .mejs-time-current,
    .select2-container--open .select2-dropdown.select2-dropdown--filters .select2-results .select2-results__options::-webkit-scrollbar-thumb
    {
        background-color: {$color};
    }

    .slick-dots li button,
    .slick-arrow,
    .custom-page:not(._shop) .custom-page__content > blockquote,
    .article__content > blockquote,
    .movies-slider-item .movies-slider-image .movies-slider-imdb,
    .movies-slider-item .movies-slider-wrapper .movies-slider-genres a:hover,
    .movies-filter-item .movies-filter-wrapper .movies-filter-image .movies-filter-imdb,
    ._movie-details-content ._movie-details-fields ._movie-details-field a:hover,
    .header .header__body .header__controls.controls .controls__menu.menu,
    .footer .footer__body .footer__right-side.right-side .right-side__scroll-up,
    .popup_js-form .popup__body,
    .pagination .page-numbers.current, .pagination .page-numbers:hover,
    .comments-area .comment-body .comment-avatar .comment-wrapper .comment-image,
    .comments-area .comment-respond .comment-reply-title #cancel-comment-reply-link,
    .select2-container--open .select2-dropdown.select2-dropdown--filters .select2-results .select2-results__options,
    .movie-details .movie-details__body .movie-details__article.article .article__tabs.tabs #tabs__nav .tabs__btn._active,
    .table-orders .table-orders__body .table-orders__form .table-orders__wrapp .table-orders__input._error,
    .table-orders .table-orders__body .table-orders__form .table-orders__wrapp .table-orders__textarea._error,
    .table-orders .table-orders__body .table-orders__pending.pending table tr th,
    .table-orders .table-orders__body .table-orders__pending.pending table tr td,
    .table-orders .table-orders__body .table-orders__pending.pending table tr th:first-child,
    .table-orders .table-orders__body .table-orders__pending.pending table tr td:first-child,
    .header .smart-search .smart-search__results .results__list,
    .header .smart-search .smart-search__results .results__list .results__item a:hover,
    .profile .profile-wrapper .profile-picture .upload-thumb,
    .profile .profile-wrapper .profile-picture > div .file-upload span
    {
        border-color: {$color};
    }

    .slick-arrow::after,
    .custom-page:not(._shop) .custom-page__content a,
    .article__content a,
    .posts-item .posts-date,
    .posts-item .posts-wrapper > a:hover .posts-title,
    .posts-item .posts-info .posts-right-side .posts-link i,
    .movies-slider-item .movies-slider-wrapper .movies-slider-genres,
    .movies-slider-item .movies-slider-wrapper .movies-slider-genres a,
    ._movie-details-content ._movie-details-title:hover a,
    ._movie-details-content ._movie-details-fields ._movie-details-field a,
    ._movie-details-content ._movie-details-fields ._movie-details-field p,
    ._movie-details-content ._movie-details-fields ._movie-details-field .delimiter,
    .header .header__body .header__controls.controls .controls__search i,
    .header .header__body .header__controls.controls .controls__menu.menu ul li a:hover,
    .footer .footer__body .footer__right-side.right-side .right-side__menu.menu ul li a:hover,
    .footer .footer__body .footer__right-side.right-side .right-side__scroll-up i,
    .breadcrumbs,
    .breadcrumbs .breadcrumbs__item a,
    .pagination .page-numbers.current, .pagination .page-numbers:hover,
    .pagination .page-numbers.current i, .pagination .page-numbers:hover i,
    .comments-area .comment-body .comment-meta-data .comment-meta-item,
    .comments-area .comment-body .comment-content .comment-context .comment-meta-item a.comment-edit-link,
    .comments-area .comment-respond .comment-reply-title #cancel-comment-reply-link,
    .select2-container--open .select2-dropdown.select2-dropdown--filters .select2-results .select2-results__options .select2-results__option.select2-results__option--highlighted[aria-selected], .select2-container--open .select2-dropdown.select2-dropdown--filters .select2-results .select2-results__options .select2-results__option.select2-results__option--highlighted[data-selected],
    .post-details .article__footer .article__share.share .share__list .share__item .share__link i,
    .movie-details .article__footer .article__share.share .share__list .share__item .share__link i,
    .select2-container--open .select2-dropdown.select2-dropdown--filters .select2-results .select2-results__options .select2-results__option.select2-results__option[aria-selected=true], .select2-container--open .select2-dropdown.select2-dropdown--filters .select2-results .select2-results__options .select2-results__option.select2-results__option[data-selected=true],
    .header .smart-search .smart-search__results .results__list .results__item a:hover,
    .profile .profile-wrapper .profile-picture > div .file-upload span
    {
        color: {$color};
    }

    #preloder .preloder__ripple div:after,
    #notfound .notfound a 
    {
        background: {$color};
    }

    ._btn, .comments-area .comment-respond .comment-form .form-submit input[type=submit],
    input[type=submit],
    .header .header__body .header__controls.controls .controls__menu.menu,
    .footer .footer__body .footer__right-side.right-side .right-side__scroll-up,
    .comments-area .comment-body .comment-avatar .comment-wrapper .comment-image,
    .profile .profile-wrapper .profile-picture .upload-thumb
    {
        box-shadow: 0px 0px 16px {$rgba};
    }

    .select2-container--open .select2-dropdown.select2-dropdown--filters .select2-results .select2-results__options,
    .header .smart-search .smart-search__results .results__list {
        box-shadow: 0px 5px 25px {$rgba};
    }

    .movies-slider-item .movies-slider-image .movies-slider-overlay,
    .middle .middle__body .middle__grid .middle__soon.soon .widget ul li span
    {
        background-color: {$rgba};
    }
	";

    wp_register_style('css-inline-styles', false, array(), true, true);
    wp_add_inline_style('css-inline-styles', $styles);
    wp_enqueue_style('css-inline-styles');
}
add_action('wp_enqueue_scripts', 'mvt_css_inline_styles');
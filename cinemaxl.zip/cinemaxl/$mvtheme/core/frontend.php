<?php

/**
 * Enqueue Theme Styles
 */
function mvt_enqueue_styles()
{
    wp_enqueue_style('animate', MVTHEME_THEME_URL . '/assets/css/libs/animate.min.css', array(), MVTHEME_THEME_VERSION, 'all');

    if (is_front_page() || is_page('table-orders')) {
        wp_enqueue_style('select2', MVTHEME_THEME_URL . '/assets/css/libs/select2.min.css', array(), MVTHEME_THEME_VERSION, 'all');
    }

    if (is_single() && 'movies' == get_post_type()) {
        wp_enqueue_style('lightbox', MVTHEME_THEME_URL . '/assets/css/libs/lightbox.min.css', array(), MVTHEME_THEME_VERSION, 'all');
        wp_enqueue_style('wp-mediaelement');
    }

    wp_enqueue_style('cinemaxl-styles', MVTHEME_THEME_URL . '/assets/css/styles.min.css', array(), MVTHEME_THEME_VERSION, 'all');
}
add_action('wp_enqueue_scripts', 'mvt_enqueue_styles');


/**
 * Enqueue Theme Scripts
 */
function mvt_enqueue_scripts()
{
    // Libs
    wp_enqueue_script('wow', MVTHEME_THEME_URL . '/assets/js/libs/wow.min.js', array('jquery'), MVTHEME_THEME_VERSION, true);
    wp_enqueue_script('slick', MVTHEME_THEME_URL . '/assets/js/libs/slick.min.js', array('jquery'), MVTHEME_THEME_VERSION, true);

    if (is_front_page() || is_page('table-orders')) {
        wp_enqueue_script('select2', MVTHEME_THEME_URL . '/assets/js/libs/select2.min.js', array('jquery'), MVTHEME_THEME_VERSION, true);
    }

    if (is_single() && 'movies' == get_post_type()) {
        wp_enqueue_script('lightbox', MVTHEME_THEME_URL . '/assets/js/libs/lightbox.min.js', array('jquery'), MVTHEME_THEME_VERSION, true);
        wp_enqueue_script('wp-mediaelement');
    }

    wp_enqueue_script('cinemaxl-scripts', MVTHEME_THEME_URL . '/assets/js/scripts.min.js', array('jquery'), MVTHEME_THEME_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'mvt_enqueue_scripts');

/**
 * Display custom RSS url
 */
function mvt_rss()
{
    echo mvt_get_rss();
}

/**
 * Get custom RSS url
 */
function mvt_get_rss()
{
    $rss_url = mvt_get_option('feedburner');
    return $rss_url ? $rss_url : get_bloginfo('rss2_url');
}

/**
 * Add header information 
 */
function mvt_head()
{
?>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> <?php esc_html_e('RSS Feed', 'cinemaxl') ?>" href="<?php mvt_rss(); ?>" />
    <link rel="preconnect" href="//fonts.gstatic.com">
<?php
}
add_action('wp_head', 'mvt_head');

/**
 * Register Fonts
 */
function mvt_google_fonts_url()
{
    $font_url = '';

    /* Get fonts names selected by administrator in theme options */

    $font_family = mvt_get_option('font_family');

    $font_style = mvt_get_option('font_style');

    $default_fonts = mvt_get_safe_webfonts();

    $load_urls = '';

    if (in_array($font_family, $default_fonts)) {
        $load_urls .= "";
    } else {
        $load_urls .= str_replace('+', ' ', $font_family) . ":" . $font_style . "|";
    }

    /*
    Translators: If there are characters in your language that are not supported
    by chosen font(s), translate this to 'off'. Do not translate into your own language.
     */
    if ('off' !== _x('on', 'Google font: on or off', 'cinemaxl')) {
        $font_url = add_query_arg('family', urlencode($load_urls), "//fonts.googleapis.com/css");
    }
    return $font_url;
}

/**
 * Enqueue scripts and styles.
 */

/*
function mvt_google_fonts_scripts()
{
    wp_enqueue_style('google-fonts', mvt_google_fonts_url(), array(), MVTHEME_THEME_VERSION);
}
add_action('wp_enqueue_scripts', 'mvt_google_fonts_scripts');
*/

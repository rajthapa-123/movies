<?php
/****************************************************************
 * Includes Parts
 ****************************************************************/

require_once CORE_PATH . '/system.php';
require_once CORE_PATH . '/backend.php';
require_once CORE_PATH . '/frontend.php';
require_once CORE_PATH . '/css-inline-styles.php';
<?php

/**
 * Get current theme options
 * 
 * @return array
 */
function mvt_get_options()
{
	$headerfont = array_merge(mvt_get_safe_webfonts(), mvt_get_google_webfonts());

	$options = array();

	/* Display */

	$options[] = array(
		"name" => esc_html__("Display", "cinemaxl"),
		"type" => "heading",
		"icon" => "dashicons-format-image"
	);

	$options["mvt_logo"] = array(
		"id" => "mvt_logo",
		"type" => "upload",
		"name" => esc_html__("Logo", "cinemaxl"),
		"desc" => esc_html__("Recommend size: 174 x 51", "cinemaxl"),
	);

	$options["mvt_main_color"] = array(
		"id" => "mvt_main_color",
		"type" => "color",
		"name" => esc_html__("Color", "cinemaxl"),
		"desc" => esc_html__("Default value: #009688", "cinemaxl"),
		"std"  => "#009688"
	);

	$options["mvt_home_bg"] = array(
		"id" => "mvt_home_bg",
		"type" => "upload",
		"name" => esc_html__("Background - Home Page", "cinemaxl"),
		"desc" => esc_html__("Recommend size: 1440 x 870", "cinemaxl"),
	);

	$options["mvt_movies_bg"] = array(
		"id" => "mvt_movies_bg",
		"type" => "upload",
		"name" => esc_html__("Background - Movies Page", "cinemaxl"),
		"desc" => esc_html__("Recommend size: 1440 x 870", "cinemaxl"),
	);
	
	return $options;
}

function __return_false_value($value)
{
	return $value;
}
add_filter('__return_false', '__return_false_value');

/**
 * Front End Customizer
 *
 * WordPress 3.4 Required
 */

add_action('customize_register', 'options_theme_customizer_register');

function options_theme_customizer_register($wp_customize)
{

	/**
	 * This is optional, but if you want to reuse some of the defaults
	 * or values you already have built in the options panel, you
	 * can load them into $options for easy reference
	 */

	$options = optionsframework_options();

	/* Basic */

	$wp_customize->add_section(
		'options_theme_customizer_basic',
		array(
			'title' => esc_html__('Basic', 'cinemaxl'),
			'priority' => 100
		)
	);

	/* Display */

	$wp_customize->add_setting('options_theme_customizer[mvt_logo]', array(
		'type' => 'option',
		'default' => $options['mvt_logo']['std'],
		'sanitize_callback' => '__return_false',
	));

	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mvt_logo', array(
		'label' => $options['mvt_logo']['name'],
		'section' => 'options_theme_customizer_basic',
		'settings' => 'options_theme_customizer[mvt_logo]'
	)));

	$wp_customize->add_setting('options_theme_customizer[mvt_main_color]', array(
		'type' => 'option',
		'default' => $options['mvt_main_color']['std'],
		'sanitize_callback' => '__return_false',
	));

	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'mvt_main_color', array(
		'label' => $options['mvt_main_color']['name'],
		'section' => 'options_theme_customizer_basic',
		'settings' => 'options_theme_customizer[mvt_main_color]'
	)));

	$wp_customize->add_setting('options_theme_customizer[mvt_home_bg]', array(
		'type' => 'option',
		'default' => $options['mvt_home_bg']['std'],
		'sanitize_callback' => '__return_false',
	));

	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mvt_home_bg', array(
		'label' => $options['mvt_home_bg']['name'],
		'section' => 'options_theme_customizer_basic',
		'settings' => 'options_theme_customizer[mvt_home_bg]'
	)));

	$wp_customize->add_setting('options_theme_customizer[mvt_movies_bg]', array(
		'type' => 'option',
		'default' => $options['mvt_movies_bg']['std'],
		'sanitize_callback' => '__return_false',
	));

	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mvt_movies_bg', array(
		'label' => $options['mvt_movies_bg']['name'],
		'section' => 'options_theme_customizer_basic',
		'settings' => 'options_theme_customizer[mvt_movies_bg]'
	)));
}

/***************************************************************
 **********************  METABOX  ******************************
 ****************************************************************/

/**
 * Add Metaboxes
 * @param array $meta_boxes
 * @return array 
 */
function mvtheme_metaboxes($meta_boxes)
{

	$meta_boxes = array();

	$prefix = "mvtheme_";

	$meta_boxes[] = array(
		'id'         => 'movies_metaboxes',
		'title'      => 'Movie Fields',
		'pages'      => array('movies',), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		// 'show_on'    => array('key' => 'page-template', 'value' => 'template-home.php'),), // Specific post templates to display this metabox
		'fields' => array(
			array(
				'name' => esc_html__('IMDb rating', 'cinemaxl'),
				'id'   => $prefix . 'movies_rating_imdb',
				'std'  => '',
				'type' => 'text',
			),
			array(
				'name' => esc_html__('Running time', 'cinemaxl'),
				'id'   => $prefix . 'movies_time',
				'std'  => '',
				'type' => 'text',
			),
			array(
				'name' => esc_html__('Premiere', 'cinemaxl'),
				'id'   => $prefix . 'movies_premiere',
				'std'  => '',
				'type' => 'text_date',
			),
			array(
				'name' => esc_html__('Link', 'cinemaxl'),
				'id'   => $prefix . 'movies_link',
				'std'  => '',
				'type' => 'text',
			),
			array(
				'name' => esc_html__('Format', 'cinemaxl'),
				'id'   => $prefix . 'movies_format',
				'std'  => 'video/youtube',
				'type' => 'select',
				'options' => array(
					array('name' => 'mp4', 'value' => 'video/mp4'),
					array('name' => 'flv', 'value' => 'video/flv'),
					array('name' => 'vimeo', 'value' => 'video/vimeo'),
					array('name' => 'rtmp', 'value' => 'video/rtmp'),
					array('name' => 'youtube', 'value' => 'video/youtube'),
					array('name' => 'vimeo', 'value' => 'video/vimeo'),
				)
			),
			array(
				'name' => esc_html__('Featured', 'cinemaxl'),
				'desc' => esc_html__('Select a collection to display in the slider (featured movies).', 'cinemaxl'),
				'id'   => $prefix . 'movies_featured',
				'std'  => '',
				'type' => 'taxonomy_multicheck',
				'taxonomy' => 'collections'
			),
		)
	);

	$meta_boxes[] = array(
		'id'         => 'advertising_metaboxes',
		'title'      => 'Advertising Fields',
		'pages'      => array('advertising',), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		// 'show_on'    => array('key' => 'page-template', 'value' => 'template-home.php'),), // Specific post templates to display this metabox
		'fields' => array(
			array(
				'name' => esc_html__('Link to resource', 'cinemaxl'),
				'id'   => $prefix . 'advertising_link',
				'std'  => '',
				'type' => 'text',
			),
		)
	);

	return $meta_boxes;
}

/**
 * Get image sizes for images
 * 
 * @return array
 */
function mvt_get_images_sizes()
{
	return array(
		'post' => array(
			array(
				'name'      => 'post-single',
				'width'     => 750,
				'height'    => 420,
				'crop'      => true,
			),
			array(
				'name'      => 'post-archive',
				'width'     => 360,
				'height'    => 280,
				'crop'      => true,
			),
		),
		'movies' => array(
			array(
				'name'      => 'movies-single',
				'width'     => 263,
				'height'    => 360,
				'crop'      => true,
			),
			array(
				'name'      => 'movies-archive',
				'width'     => 263,
				'height'    => 360,
				'crop'      => true,
			),
		),
		'advertising' => array(
			array(
				'name'      => 'advertising',
				'width'     => 200,
				'height'    => 280,
				'crop'      => true,
			)
		)
	);
}

add_image_columns_in_post_types(esc_html__('Thumbs', 'cinemaxl'), array('movies', 'advertising'));

/**
 * This function modifies the main WordPress query to include an array of 
 * post types instead of the default 'post' post type.
 *
 * @param object $query The main WordPress query.
 */
function mvtheme_include_custom_post_types_in_search_results($query)
{
	if ($query->is_main_query() && $query->is_search() && !is_admin()) {
		$query->set('post_type', array('movies'));
	}
}
add_action('pre_get_posts', 'mvtheme_include_custom_post_types_in_search_results');

<?php

get_header();
?>

<section <?php post_class('post-details'); ?> id="post-<?php the_ID() ?>" data-post-id="<?php the_ID() ?>">
	<div class="post-details__container _container">
		<div class="post-details__body">
			<?php get_template_part('template-parts/heading', null, array('extra_class' => 'post-details__heading')); ?>
			<?php if (have_posts()) : ?>
				<?php while (have_posts()) : the_post(); ?>
					<article class="post-details__article article">
						<div class="article__image">
							<div class="article__overlay">
								<?php echo get_the_post_thumbnail($post->ID, 'post-single') ?>
							</div>
							<div class="article__signature signature">
								<div class="signature__author"><?php esc_html_e('by', 'cinemaxl') ?> <?php the_author(); ?></div>
								<time datetime="<?php echo get_the_date('Y-m-d'); ?>" class="signature__date"><?php echo get_the_date('d M Y'); ?></time>
							</div>
						</div>
						<h2 class="article__title">
							<?php the_title(); ?>
						</h2>
						<div class="article__content">
							<?php the_content(); ?>
						</div>
						<div class="article__footer">
							<?php if (is_array(get_the_tags()) && count(get_the_tags()) > 0) : ?>
								<div class="article__tags tags">
									<div class="tags__title"><?php esc_html_e('Tags:', 'cinemaxl') ?></div>
									<?php the_tags('<div class="tags__list">', '', '</div>') ?>
								</div>
							<?php endif; ?>
							<div class="article__share share">
								<ul class="share__list">
									<li class="share__item">
										<!--noindex-->
										<a onclick="window.open(this.href, 'Share on Facebook', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('facebook', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
											<i class="icon-facebook"></i>
										</a>
										<!--/noindex-->
									</li>
									<li class="share__item">
										<!--noindex-->
										<a onclick="window.open(this.href, 'Share on LinkedIn', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('linkedin', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
											<i class="icon-linkedin"></i>
										</a>
										<!--/noindex-->
									</li>
									<li class="share__item">
										<!--noindex-->
										<a onclick="window.open(this.href, 'Share on Twitter', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('twitter', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
											<i class="icon-twitter"></i>
										</a>
										<!--/noindex-->
									</li>
									<li class="share__item">
										<!--noindex-->
										<a onclick="window.open(this.href, 'Share on Instagram', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('instagram', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
											<i class="icon-instagram"></i>
										</a>
										<!--/noindex-->
									</li>
								</ul>
							</div>
						</div>
					</article>
				<?php endwhile; ?>
			<?php else : ?>
				<?php get_template_part('template-parts/notfound'); ?>
			<?php endif; ?>
			<?php if (comments_open() || get_comments_number()) : ?>
				<div class="post-details__comments">
					<?php comments_template(); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section><!-- #post-details -->

<?php
get_footer();

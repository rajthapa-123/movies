<?php
get_header();
?>

<div id="notfound">
	<div class="notfound">
		<div class="notfound-404">
			<h1><?php esc_html_e('Opps!', 'cinemaxl')?></h1>
			<h2><?php esc_html_e('404 - wrong way', 'cinemaxl')?></h2>
		</div>
		<a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Go to homepage', 'cinemaxl')?></a>
	</div>
</div>

<?php
get_footer();
<?php

if (post_password_required()) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php
	// You can start editing here -- including this comment!
	if (have_comments()) :
	?>
		<h2 class="comments-title">
			<?php
			$e_ookslib_comment_count = get_comments_number();
			if ('1' === $e_bookslib_comment_count) {
				printf(
					/* translators: 1: title. */
					esc_html__('One thought on &ldquo;%1$s&rdquo;', 'cinemaxl'),
					'<span>' . wp_kses_post(get_the_title()) . '</span>'
				);
			} else {
				printf(
					/* translators: 1: comment count number, 2: title. */
					esc_html(_nx('%1$s thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', $e_bookslib_comment_count, 'comments title', 'cinemaxl')),
					number_format_i18n($e_bookslib_comment_count), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					'<span>' . wp_kses_post(get_the_title()) . '</span>'
				);
			}
			?>
		</h2><!-- .comments-title -->

		<?php the_comments_navigation(); ?>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'callback' => 'mvt_comment',
					'end-callback' => 'mvt_comment_close',
				)
			);
			?>
		</ol><!-- .comment-list -->

		<?php
		the_comments_navigation();

		// If comments are closed and there are comments, let's leave a little note, shall we?
		if (!comments_open()) :
		?>
			<p class="no-comments"><?php esc_html_e('Comments are closed.', 'cinemaxl'); ?></p>
	<?php
		endif;

	endif; // Check for have_comments().

	$commenter = wp_get_current_commenter();
	$req      = get_option('require_name_email');
	$html_req = ($req ? " required='required'" : '');
	$html5    = current_theme_supports('html5', 'comment-form');

	$fields = array(
		'author' => '<div class="comment-form-container">' . '<div class="comment-form-group-feilds">' . '<div class="comment-form-feild-wrapp">' . '<input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30" maxlength="245"' . $html_req . ' placeholder="' . __('Your Name*', 'cinemaxl') . '" /> ' . '</div>',
		'email'  => '<div class="comment-form-feild-wrapp">' . '<input id="email" name="email" ' . ($html5 ? 'type="email"' : 'type="text"') . ' value="' . esc_attr($commenter['comment_author_email']) . '" size="30" maxlength="100" aria-describedby="email-notes"' . $html_req  . ' placeholder="' . __('Your Email*', 'cinemaxl') . '" />' . '</div>' . '</div>',
		'cookies' => '<div class="comment-form-cookies-consent">' . '<input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes"/>' . '<label for="wp-comment-cookies-consent">' . __('Save my name, email, and website in this browser for the next time I comment.', 'cinemaxl') . '</label>' . '</div>',
	);

	$args = array(
		'comment_notes_after' => '',
		'comment_notes_after' => '',
		'title_reply' => __('Add comment', 'cinemaxl'),
		'label_submit' => __('Submit Comment', 'cinemaxl'),
		'comment_field' => !is_user_logged_in() ? '<div class="comment-form-textarea-wrapp"><textarea id="comment" placeholder="' . __('Сomment*', 'cinemaxl') . '" name="comment" maxlength="65525" aria-required="true" required="required"></textarea></div></div>' : '<div class="comment-form-textarea-wrapp"><textarea id="comment" placeholder="' . __('Сomment*', 'cinemaxl') . '" name="comment" maxlength="65525" aria-required="true" required="required"></textarea></div>',
		'fields' => apply_filters('comment_form_default_fields', $fields)
	);

	comment_form($args);
	?>

</div><!-- #comments -->
/******************************************************************
SHORT INFORMATION
******************************************************************/
Online Documentation – https://mv-theme.pro/docs/wordpress/cinemaxl/

Support Forum – https://support.mv-theme.pro

/******************************************************************
CHANGE LOG
******************************************************************/

v.1.0.2

Fixed bugs with search

/$mvtheme/features/breadcrumbs.php (string 26)

plugins/cinemaxl-addon/includes/custom-smart-search/custom-smart-search.php (string 91)


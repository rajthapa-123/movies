<?php

/**
 * Template Name: CinemaXL Home Page
 *
 *
 */

get_header();
?>

<!-- SECTION MIDDLE -->
<section class="middle" id="middle">
    <div class="middle__lining _lining" style="background-image: url(<?php echo !empty(mvt_get_option('home_bg')) ?  esc_url(mvt_get_option('home_bg')) : esc_url(get_template_directory_uri()) . "/assets/img/bg-home.png"?>);"></div>
    <div class="middle__container _container">
        <div class="middle__body">
            <?php
            $favorites = new WP_Query(array(
                'post_type' => 'movies',
                'posts_per_page' => '8',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'collections',
                        'field' => 'slug',
                        'terms' => 'favorites'
                    )
                )
            ));
            ?>
            <?php if ($favorites->have_posts()) : ?>
                <div class="middle__movies-slider movies-slider">
                    <?php while ($favorites->have_posts()) : $favorites->the_post(); ?>
                        <?php get_template_part('template-parts/movies', 'slider'); ?>
                    <?php endwhile; ?>
                    <?php wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>

            <form class="middle__movies-filters movies-filters">
                <div class="movies-filters__wrapper">
                    <?php
                    $genres = get_terms(array(
                        'taxonomy' => 'genres',
                        'orderby' => 'name',
                        'order' => 'DESC',
                        'parent' => 0,
                        'hide_empty' => false
                    ));
                    ?>
                    <?php if (is_array($genres) && count($genres) > 0) : ?>
                        <select name="genres_id" id="movies-filters__genres" class="movies-filters__genres">
                            <option value=""><?php echo esc_html__('All genres', 'cinemaxl') ?></option>
                            <?php
                            foreach ($genres as $item) {
                                printf(
                                    '<option value="%s"/>%s</label>',
                                    esc_attr($item->term_id),
                                    esc_attr($item->name)
                                );
                            }
                            ?>
                        </select>
                    <?php endif; ?>
                    <?php
                    $quality = get_terms(array(
                        'taxonomy' => 'quality',
                        'orderby' => 'name',
                        'order' => 'DESC',
                        'parent' => 0,
                        'hide_empty' => false
                    ));
                    ?>
                    <?php if (is_array($quality) && count($quality) > 0) : ?>
                        <select name="quality_id" id="movies-filters__quality" class="movies-filters__quality">
                            <option value=""><?php echo esc_html__('Any quality', 'cinemaxl') ?></option>
                            <?php
                            foreach ($quality as $item) {
                                printf(
                                    '<option value="%s"/>%s</label>',
                                    esc_attr($item->term_id),
                                    esc_attr($item->name)
                                );
                            }
                            ?>
                        </select>
                    <?php endif; ?>
                    <?php
                    $years = get_terms(array(
                        'taxonomy' => 'years',
                        'orderby' => 'name',
                        'order' => 'DESC',
                        'parent' => 0,
                        'hide_empty' => false
                    ));
                    ?>
                    <?php if (is_array($years) && count($years) > 0) : ?>
                        <select name="years_id" id="movies-filters__years" class="movies-filters__years">
                            <option value=""><?php echo esc_html__('Any year', 'cinemaxl') ?></option>
                            <?php
                            foreach ($years as $item) {
                                printf(
                                    '<option value="%s"/>%s</label>',
                                    esc_attr($item->term_id),
                                    esc_attr($item->name)
                                );
                            }
                            ?>
                        </select>
                    <?php endif; ?>
                    <select name="ordering" id="movies-filters__ordering" class="movies-filters__ordering">
                        <option value="" selected><?php esc_html_e('Sorting', 'cinemaxl') ?></option>
                        <option value="date"><?php esc_html_e('Sort by latest', 'cinemaxl') ?></option>
                        <option value="popularity"><?php esc_html_e('Sort by popularity', 'cinemaxl') ?></option>
                        <option value="comment-count"><?php esc_html_e('Sort by number of comments: low to high', 'cinemaxl') ?></option>
                        <option value="comment-count-desc"><?php esc_html_e('Sort by number of comments: high to low', 'cinemaxl') ?></option>
                        <option value="rating-imdb"><?php esc_html_e('Sort by rating IMDb: low to high', 'cinemaxl') ?></option>
                        <option value="rating-imdb-desc"><?php esc_html_e('Sort by rating IMDb: high to low', 'cinemaxl') ?></option>
                    </select>
                </div>
                <button class="movies-filters__btn _btn">
                    <?php esc_html_e('APPLY', 'cinemaxl') ?>
                </button>
            </form>

            <div class="middle__grid">
                <?php if (is_active_sidebar('movies-sidebar')) : ?>
                    <div class="middle__soon soon">
                        <?php dynamic_sidebar('movies-sidebar'); ?>
                    </div>
                <?php endif; ?>
                <div class="middle__movies movies">
                    <div class="movies__list">
                        <?php
                        $args = array(
                            'post_type'        => 'movies',
                            'posts_per_page'   => get_option('posts_per_page'),
                        );

                        $loop = new WP_Query($args);

                        if ($loop->have_posts()) :
                            while ($loop->have_posts()) :
                                $loop->the_post();
                                get_template_part('template-parts/movies', 'filter');
                            endwhile;
                            custom_paginate_links($loop, '_ajax');
                        else :
                            get_template_part('template-parts/notfound');
                        endif;
                        wp_reset_postdata();
                        ?>
                    </div>
                    <?php if (get_the_content()) : ?>
                        <div class="movies__story">
                            <?php the_content(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>


            <?php
            $news = new WP_Query(array(
                'post_type' => 'post',
                'posts_per_page' => '3'
            )); ?>
            <?php if ($news->have_posts()) : ?>
                <div class="middle__posts">
                    <?php while ($news->have_posts()) : $news->the_post(); ?>
                        <div class="posts-item">
                            <a href="<?php the_permalink(); ?>">
                                <div class="posts-image">
                                    <?php echo get_the_post_thumbnail(get_the_ID(), 'post-archive'); ?>
                                </div>
                            </a>
                            <time datetime="<?php echo get_the_date('Y-m-d'); ?>" class="posts-date"><?php echo get_the_date('d M Y'); ?></time>
                            <div class="posts-wrapper">
                                <a href="<?php the_permalink(); ?>">
                                    <h4 class="posts-title"><?php the_title(); ?></h4>
                                </a>
                            </div>
                            <div class="posts-info">
                                <div class="posts-left-side">
                                    <div class="posts-category"><?php echo get_the_category(get_the_ID())[0]->name; ?></div>
                                    <span class="posts-separator">|</span>
                                    <div class="posts-comments"><?php echo get_custom_comments_number(get_the_ID()); ?></div>
                                </div>
                                <div class="posts-right-side">
                                    <a href="<?php the_permalink(); ?>" class="posts-link"><i class="posts-arrow icon-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>

<?php
get_footer();

<?php

/****************************************************************
 * DO NOT DELETE
 ****************************************************************/
define('THEME_FOLDER', 'cinemaxl');
if (get_stylesheet_directory() == get_template_directory()) {
    define('ROOT_PATH', get_template_directory() . '/$mvtheme');
    define('ROOT_URL', esc_url(get_template_directory_uri()) . '/$mvtheme');
} else {
    define('ROOT_PATH', get_theme_root() . '/' . THEME_FOLDER . '/$mvtheme');
    define('ROOT_URL', get_theme_root_uri() . '/' . THEME_FOLDER . '/$mvtheme');
}

require_once ROOT_PATH . '/inc.php';

/****************************************************************
 * Parent theme functions should not be edited.
 * 
 * If you want to add custom functions you should use child theme.
 ****************************************************************/
<?php

?>

<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<!-- PRELODER START -->
	<div id="preloder">
		<div class="preloder__ripple">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
	</div>
	<!-- PRELODER END -->
	<div id="page">
		<header id="header" class="header">
			<div class="header__container _container">
				<div class="header__body">
					<a href="<?php echo esc_url(home_url('/')); ?>" class="header__logo logo">
						<?php if (!empty(mvt_get_option('logo'))) : ?>
							<img src="<?php echo esc_url(mvt_get_option('logo')); ?>" alt="<?php bloginfo('name') ?>" class="logo__img">
						<?php else : ?>
							<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/logo.png" alt="<?php bloginfo('name') ?>" class="logo__img">
						<?php endif; ?>
					</a>
					<div class="header__search-panel search-panel">
						<div class="search-panel__close"></div>
						<?php do_shortcode('[smart_search_form]') ?>
					</div>
					<div class="header__controls controls">
						<button class="controls__search">
							<i class="icon-search"></i>
						</button>
						<button class="controls__burger">
							<span></span>
						</button>
						<nav class="controls__menu menu" onclick="event.stopPropagation();">
							<?php wp_nav_menu(array(
								'theme_location'  => 'header_menu',
								'container'       => 'ul',
								'menu_class'      => 'menu__list',
								'link_before'     => '<span>',
								'link_after'      => '</span>',
							)); ?>
						</nav>
						<div class="controls__entry entry">
							<?php if (is_user_logged_in()) : ?>
								<a href="<?php echo wp_logout_url(home_url()); ?>" class="entry__logout _btn"><span><?php esc_html_e('Logout', 'cinemaxl'); ?></span></a>
							<?php else : ?>
								<button class="entry__login _btn" id="show_login"><span><?php esc_html_e('Login', 'cinemaxl'); ?></span></button>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</header><!-- #masthead -->
		<main class="core">
<?php

get_header();
?>

<section class="archive-area _archives" id="archive-area">
	<div class="archive-area__container _container">
		<div class="archive-area__body">
		<?php get_template_part('template-parts/heading', null, array('extra_class' => 'archive-area__heading')); ?>
			<?php if (have_posts()) : ?>
				<?php if (is_tax(array('collections', 'years', 'countries', 'genres', 'quality', 'directors', 'actors')) || is_post_type_archive(array('movies'))) : ?>
					<div class="archive-area__wrapper">
						<?php while (have_posts()) : ?>
							<?php the_post();  ?>
							<?php get_template_part('template-parts/movies', 'filter'); ?>
						<?php endwhile; ?>
					</div>
				<?php else : ?>
					<div class="archive-area__posts">
						<?php while (have_posts()) : the_post(); ?>
							<div class="posts-item">
								<a href="<?php the_permalink(); ?>">
									<div class="posts-image">
										<?php echo get_the_post_thumbnail(get_the_ID(), 'post-archive'); ?>
									</div>
								</a>
								<time datetime="<?php echo get_the_date('Y-m-d'); ?>" class="posts-date"><?php echo get_the_date('d M Y'); ?></time>
								<div class="posts-wrapper">
									<a href="<?php the_permalink(); ?>">
										<h4 class="posts-title"><?php the_title(); ?></h4>
									</a>
								</div>
								<div class="posts-info">
									<div class="posts-left-side">
										<div class="posts-category"><?php echo get_the_category(get_the_ID())[0]->name; ?></div>
										<span class="posts-separator">|</span>
										<div class="posts-comments"><?php echo get_custom_comments_number(get_the_ID()); ?></div>
									</div>
									<div class="posts-right-side">
										<a href="<?php the_permalink(); ?>" class="posts-link"><i class="posts-arrow icon-arrow-right"></i></a>
									</div>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
				<?php endif; ?>
				<?php custom_paginate_links() ?>
			<?php else : ?>
				<?php get_template_part('template-parts/notfound'); ?>
			<?php endif; ?>
		</div>
	</div>
</section>

<?php
get_footer();

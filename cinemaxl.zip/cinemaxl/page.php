<?php

get_header();
?>

<section class="custom-page" id="custom-page">
    <div class="custom-page__container _container">
        <div class="custom-page__body">
            <?php get_template_part('template-parts/heading', null, array('extra_class' => 'custom-page__heading')); ?>
            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <div class="custom-page__content">
                        <?php the_content(); ?>

                        <?php wp_link_pages(array(
                            'before' => '<p class="custom-page__pages">',
                            'after'     => '</p>',
                        )) ?>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <?php get_template_part('template-parts/notfound'); ?>
            <?php endif; ?>
            <?php if (comments_open() || get_comments_number()) : ?>
                <div class="custom-page__comments">
                    <?php comments_template(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php
get_footer();

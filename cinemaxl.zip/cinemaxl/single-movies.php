<?php

get_header();
?>

<section id="movie-details" class="movie-details">
	<div class="movie-details__lining _lining" style="background-image: url(<?php echo !empty(mvt_get_option('movies_bg')) ?  esc_url(mvt_get_option('movies_bg')) : esc_url( get_template_directory_uri() ) . "/assets/img/bg-movies.png"?>);"></div>
	<div class="movie-details__container _container">
		<div class="movie-details__body">
			<?php get_template_part('template-parts/heading', null, array('extra_class' => 'movie-details__heading')); ?>
			<?php while (have_posts()) : the_post(); ?>
				<article class="movie-details__article article">
					<div class="article__wrapper">
						<div class="article__info">
							<div class="article__image">
								<?php
								if (has_post_thumbnail()) {
									the_post_thumbnail('movies-single');
								} else {
									echo '<img src="' . get_template_directory_uri() . '/assets/img/placeholder.jpg' . '" alt="placeholder">';
								}
								?>
							</div>
							<div class="_movie-details-content">
								<h3 class="_movie-details-title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h3>
								<div class="_movie-details-graphic">
									<?php if (mvt_get_meta('movies_rating_imdb')) : ?>
										<div class="_movie-details-rating">
											<i class="icon-rating"></i>
											<span><?php echo esc_html(mvt_get_meta('movies_rating_imdb')) ?></span>
										</div>
									<?php endif; ?>
									<?php
									$quality = get_the_terms(get_the_ID(), 'quality');
									?>
									<?php if (is_array($quality) && count($quality) > 0) : ?>
										<div class="_movie-details-quality">
											<?php foreach ($quality as $item) : ?>
												<span><?php echo esc_html($item->name); ?></span>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
								</div>
								<div class="_movie-details-fields">
									<?php
									$years = get_the_terms(get_the_ID(), 'years');
									$years_count = 0;
									?>
									<?php if (is_array($years) && count($years) > 0) : ?>
										<div class="_movie-details-field">
											<span class="_movie-details-label">
												<?php esc_html_e('Year:', 'cinemaxl') ?>
											</span>
											<?php foreach ($years as $year) : ?>
												<a href="<?php echo esc_url(get_term_link($year->term_id)) ?>"><?php echo esc_html($year->name); ?></a>
												<?php if (($years_count + 1) !== count($years)) : ?>
													<span class="delimiter">,</span>
												<?php endif; ?>
												<?php $years_count++; ?>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
									<?php
									$countries = get_the_terms(get_the_ID(), 'countries');
									$countries_count = 0;
									?>
									<?php if (is_array($countries) && count($countries) > 0) : ?>
										<div class="_movie-details-field">
											<span class="_movie-details-label">
												<?php esc_html_e('Country:', 'cinemaxl') ?>
											</span>
											<?php foreach ($countries as $country) : ?>
												<a href="<?php echo esc_url(get_term_link($country->term_id)) ?>"><?php echo esc_html($country->name); ?></a>
												<?php if (($countries_count + 1) !== count($countries)) : ?>
													<span class="delimiter">,</span>
												<?php endif; ?>
												<?php $countries_count++; ?>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
									<?php
									$genres = get_the_terms(get_the_ID(), 'genres');
									$genres_count = 0;
									?>
									<?php if (is_array($genres) && count($genres) > 0) : ?>
										<div class="_movie-details-field">
											<span class="_movie-details-label">
												<?php esc_html_e('Genres:', 'cinemaxl') ?>
											</span>
											<?php foreach ($genres as $genre) : ?>
												<a href="<?php echo esc_url(get_term_link($genre->term_id)) ?>"><?php echo esc_html($genre->name); ?></a>
												<?php if (($genres_count + 1) !== count($genres)) : ?>
													<span class="delimiter">,</span>
												<?php endif; ?>
												<?php $genres_count++; ?>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
									<?php if (mvt_get_meta('movies_time', true, get_the_ID())) : ?>
										<div class="_movie-details-field">
											<span class="_movie-details-label">
												<?php esc_html_e('Running time:', 'cinemaxl') ?>
											</span>
											<p><?php echo esc_html(mvt_get_meta('movies_time', true, get_the_ID())); ?></p>
										</div>
									<?php endif; ?>
									<?php if (mvt_get_meta('movies_premiere', true, get_the_ID())) : ?>
										<div class="_movie-details-field">
											<span class="_movie-details-label">
												<?php esc_html_e('Premiere:', 'cinemaxl') ?>
											</span>
											<p><?php echo esc_html(mvt_get_meta('movies_premiere', true, get_the_ID())); ?></p>
										</div>
									<?php endif; ?>
									<?php
									$directors = get_the_terms(get_the_ID(), 'directors');
									$directors_count = 0;
									?>
									<?php if (is_array($directors) && count($directors) > 0) : ?>
										<div class="_movie-details-field">
											<span class="_movie-details-label">
												<?php esc_html_e('Director:', 'cinemaxl') ?>
											</span>
											<?php foreach ($directors as $director) : ?>
												<a href="<?php echo esc_url(get_term_link($director->term_id)) ?>"><?php echo esc_html($director->name); ?></a>
												<?php if (($directors_count + 1) !== count($directors)) : ?>
													<span class="delimiter">,</span>
												<?php endif; ?>
												<?php $directors_count++; ?>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
									<?php
									$actors = get_the_terms(get_the_ID(), 'actors');
									$actors_count = 0;
									?>
									<?php if (is_array($actors) && count($actors) > 0) : ?>
										<div class="_movie-details-field _lh">
											<span class="_movie-details-label">
												<?php esc_html_e('Actors:', 'cinemaxl') ?>
											</span>
											<?php foreach ($actors as $actor) : ?>
												<a href="<?php echo esc_url(get_term_link($actor->term_id)) ?>"><?php echo esc_html($actor->name); ?></a>
												<?php if (($actors_count + 1) !== count($actors)) : ?>
													<span class="delimiter">,</span>
												<?php endif; ?>
												<?php $actors_count++; ?>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="article__player player">
							<video class="mejs__player" width="100%" height="100%" style="width:100%;height:100%;">
								<?php
								switch (mvt_get_meta('movies_format')) {
									case 'video/mp4':
										echo '<source type="video/mp4" src="' . esc_url(mvt_get_meta('movies_link')) . '" />';
										break;
									case 'video/flv':
										echo '<source type="video/flv" src="' . esc_url(mvt_get_meta('movies_link')) . '" />';
										break;
									case 'video/vimeo':
										echo '<source type="video/vimeo" src="' . esc_url(mvt_get_meta('movies_link')) . '" />';
										break;
									case 'video/rtmp':
										echo '<source type="video/rtmp" src="' . esc_url(mvt_get_meta('movies_link')) . '" />';
										break;
									case 'video/youtube':
										echo '<source type="video/youtube" src="' . esc_url(mvt_get_meta('movies_link')) . '" />';
										break;
									case 'video/vimeo':
										echo '<source type="video/vimeo" src="' . esc_url(mvt_get_meta('movies_link')) . '" />';
										break;
								}
								?>
							</video>
						</div>
					</div>

					<div class="article__tabs tabs">
						<div id="tabs__nav">
							<?php if (get_the_content()) : ?>
								<div class="tabs__btn"><?php esc_html_e('Description', 'cinemaxl') ?></div>
							<?php endif; ?>
							<?php if (get_post_meta(get_the_ID(), 'mvt_gallery_id', true)) : ?>
								<div class="tabs__btn"><?php esc_html_e('Images', 'cinemaxl') ?></div>
							<?php endif; ?>
							<div class="tabs__btn"><?php esc_html_e('Comments', 'cinemaxl') ?></div>
						</div>
						<div id="tabs__content">
							<?php if (get_the_content()) : ?>
								<div class="tab__area">
									<?php the_content(); ?>
								</div>
							<?php endif; ?>
							<?php if (get_post_meta(get_the_ID(), 'mvt_gallery_id', true)) : ?>
								<div class="tab__area">
									<div class="_gallery-list">
										<?php $images = get_post_meta(get_the_ID(), 'mvt_gallery_id', true);
										foreach ($images as $image) {
											echo '<a href="' . esc_url(wp_get_attachment_url($image)) . '" class="_gallery-item" data-lightbox="movie-images">' . wp_get_attachment_image($image, array(223, 200)) . '</a>';
										}
										?>
									</div>
								</div>
							<?php endif; ?>
							<div class="tab__area">
								<?php comments_template(); ?>
							</div>
						</div>
					</div>

					<div class="article__footer">
						<div class="article__share share">
							<ul class="share__list">
								<li class="share__item">
									<!--noindex-->
									<a onclick="window.open(this.href, 'Share on Facebook', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('facebook', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
										<i class="icon-facebook"></i>
									</a>
									<!--/noindex-->
								</li>
								<li class="share__item">
									<!--noindex-->
									<a onclick="window.open(this.href, 'Share on LinkedIn', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('linkedin', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
										<i class="icon-linkedin"></i>
									</a>
									<!--/noindex-->
								</li>
								<li class="share__item">
									<!--noindex-->
									<a onclick="window.open(this.href, 'Share on Twitter', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('twitter', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
										<i class="icon-twitter"></i>
									</a>
									<!--/noindex-->
								</li>
								<li class="share__item">
									<!--noindex-->
									<a onclick="window.open(this.href, 'Share on Instagram', 'width=600,height=600'); return false" href="<?php echo mvt_get_share('instagram', get_the_permalink(), get_the_title()); ?>" class="share__link" target="_blank" rel="nofollow">
										<i class="icon-intsagram"></i>
									</a>
									<!--/noindex-->
								</li>
							</ul>
						</div>
					</div>

					<?php if (mvt_get_meta('movies_featured')) : ?>
						<div class="article__featured featured">
							<h2 class="featured__title"><?php esc_html_e('Featured', 'cinemaxl') ?></h2>
							<div class="featured__slider">
								<?php echo do_shortcode('[filter_movies_shortcode terms="' . esc_attr(implode(",", mvt_get_meta('movies_featured')))  . '"]') ?>
							</div>
						</div>
					<?php endif; ?>
				</article>
			<?php endwhile; ?>
		</div>
	</div>
</section><!-- #movie-details -->

<?php
get_footer();

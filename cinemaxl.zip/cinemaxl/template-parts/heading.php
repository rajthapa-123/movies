<div class="<?php echo !empty($args['extra_class']) ? esc_attr($args['extra_class']) : ""; ?> heading">
    <div class="heading__body">
        <h1 class="heading__title">
            <?php
            if (is_tag()) {
                esc_html_e('Tag Archive: ', 'cinemaxl') . single_tag_title('', false);
            } else if (is_singular('post')) {
                esc_html_e('Details', 'cinemaxl');
            } else if (is_search()) {
                esc_html_e('Search Results for: ', 'cinemaxl') . get_search_query();
            } else if (is_category()) {
                esc_html_e('Category: ','cinemaxl') . single_cat_title("", false);
            } else if (is_author()) {
                esc_html_e('Author: ', 'cinemaxl') . get_the_author();
            } else if (class_exists('woocommerce') && is_woocommerce()) {
                woocommerce_page_title();
            } else if (is_archive()) {
                if (is_day()) {
                    esc_html_e('Day Archive: ', 'cinemaxl') . get_the_date('d M');
                } else if (is_month()) {
                    esc_html_e('Month Archive: ', 'cinemaxl') . get_the_date('M');
                } else if (is_year()) {
                    esc_html_e('Year Archive: ', 'cinemaxl') . get_the_date('Y');
                } else {
                    the_archive_title();
                }
            } else {
                wp_title('');
            }
            ?>
        </h1>
        <?php
        if (function_exists('is_woocommerce') && is_woocommerce()) {
            woocommerce_breadcrumb();
        } else {
            get_breadcrumbs();
        }
        ?>
    </div>
</div>
<div class="movies-filter-item">
    <div class="movies-filter-wrapper">
        <a href="<?php the_permalink(); ?>" class="movies-filter-image">
            <?php
            if (has_post_thumbnail()) {
                the_post_thumbnail('movies-archive');
            } else {
                echo '<img src="' . get_template_directory_uri() . '/assets/img/placeholder.jpg' . '" alt="placeholder">';
            }
            ?>
            <?php if (mvt_get_meta('movies_rating_imdb')) : ?>
                <div class="movies-filter-imdb">
                    <?php esc_html_e('IMDb:', 'cinemaxl') ?>
                    <?php echo esc_attr(mvt_get_meta('movies_rating_imdb')) ?>
                </div>
            <?php endif; ?>
        </a>
        <div class="_movie-details-content">
            <h3 class="_movie-details-title">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h3>
            <div class="_movie-details-graphic">
                <?php
                $quality = get_the_terms(get_the_ID(), 'quality');
                ?>
                <?php if (is_array($quality) && count($quality) > 0) : ?>
                    <div class="_movie-details-quality">
                        <?php foreach ($quality as $item) : ?>
                            <span><?php echo esc_html($item->name); ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="_movie-details-fields">
                <?php
                $years = get_the_terms(get_the_ID(), 'years');
                $years_count = 0;
                ?>
                <?php if (is_array($years) && count($years) > 0) : ?>
                    <div class="_movie-details-field">
                        <span class="_movie-details-label">
                            <?php esc_html_e('Year:', 'cinemaxl') ?>
                        </span>
                        <?php foreach ($years as $year) : ?>
                            <a href="<?php echo esc_url(get_term_link($year->term_id)) ?>"><?php echo esc_html($year->name); ?></a>
                            <?php if (($years_count + 1) !== count($years)) : ?>
                                <span class="delimiter">,</span>
                            <?php endif; ?>
                            <?php $years_count++; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php
                $countries = get_the_terms(get_the_ID(), 'countries');
                $countries_count = 0;
                ?>
                <?php if (is_array($countries) && count($countries) > 0) : ?>
                    <div class="_movie-details-field">
                        <span class="_movie-details-label">
                            <?php esc_html_e('Country:', 'cinemaxl') ?>
                        </span>
                        <?php foreach ($countries as $country) : ?>
                            <a href="<?php echo esc_url(get_term_link($country->term_id)) ?>"><?php echo esc_html($country->name); ?></a>
                            <?php if (($countries_count + 1) !== count($countries)) : ?>
                                <span class="delimiter">,</span>
                            <?php endif; ?>
                            <?php $countries_count++; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php
                $genres = get_the_terms(get_the_ID(), 'genres');
                $genres_count = 0;
                ?>
                <?php if (is_array($genres) && count($genres) > 0) : ?>
                    <div class="_movie-details-field">
                        <span class="_movie-details-label">
                            <?php esc_html_e('Genres:', 'cinemaxl') ?>
                        </span>
                        <?php foreach ($genres as $genre) : ?>
                            <a href="<?php echo esc_url(get_term_link($genre->term_id)) ?>"><?php echo esc_html($genre->name); ?></a>
                            <?php if (($genres_count + 1) !== count($genres)) : ?>
                                <span class="delimiter">,</span>
                            <?php endif; ?>
                            <?php $genres_count++; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php
                $directors = get_the_terms(get_the_ID(), 'directors');
                $directors_count = 0;
                ?>
                <?php if (is_array($directors) && count($directors) > 0) : ?>
                    <div class="_movie-details-field">
                        <span class="_movie-details-label">
                            <?php esc_html_e('Director:', 'cinemaxl') ?>
                        </span>
                        <?php foreach ($directors as $director) : ?>
                            <a href="<?php echo esc_url(get_term_link($director->term_id)) ?>"><?php echo esc_html($director->name); ?></a>
                            <?php if (($directors_count + 1) !== count($directors)) : ?>
                                <span class="delimiter">,</span>
                            <?php endif; ?>
                            <?php $directors_count++; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php
                $actors = get_the_terms(get_the_ID(), 'actors');
                $actors_count = 0;
                ?>
                <?php if (mvt_get_meta('movies_time', true, get_the_ID())) : ?>
                    <div class="_movie-details-field">
                        <span class="_movie-details-label">
                            <?php esc_html_e('Running time:', 'cinemaxl') ?>
                        </span>
                        <p><?php echo esc_html(mvt_get_meta('movies_time', true, get_the_ID())); ?></p>
                    </div>
                <?php endif; ?>
                <div class="_movie-details-field">
                    <span class="_movie-details-label">
                        <?php esc_html_e('Comments:', 'cinemaxl') ?>
                    </span>
                    <p><?php echo get_comments_number(get_the_ID()) ?></p>
                </div>
            </div>
            <div class="_movie-details-description">
                <?php echo mvt_trim_excerpt(40); ?>
            </div>
        </div>
    </div>
</div>
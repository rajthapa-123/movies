<div class="movies-slider-item">
    <div class="movies-slider-image">
        <?php
        if (has_post_thumbnail()) {
            the_post_thumbnail('movies-archive');
        } else {
            echo '<img src="' . get_template_directory_uri() . '/assets/img/placeholder.jpg' . '" alt="placeholder">';
        }
        ?>
        <div class="movies-slider-overlay">
            <a href="<?php the_permalink(); ?>" class="movies-slider-play">
                <i class="icon-play"></i>
            </a>
        </div>
        <?php if (mvt_get_meta('movies_rating_imdb')) : ?>
            <div class="movies-slider-imdb">
                <?php esc_html_e('IMDb:', 'cinemaxl') ?>
                <?php echo esc_attr(mvt_get_meta('movies_rating_imdb')) ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="movies-slider-wrapper">
        <h3 class="movies-slider-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        <?php
        $genres = get_the_terms(get_the_ID(), 'genres');
        $i = 0;
        ?>
        <?php if (is_array($genres) && count($genres) > 0) : ?>
            <div class="movies-slider-genres">
                <?php foreach ($genres as $genre) : ?>
                    <a href="<?php echo esc_url(get_term_link($genre->term_id)) ?>"><?php echo esc_html($genre->name); ?></a>
                    <?php if (($i + 1) !== count($genres)) : ?>
                        <span class="delimiter">,</span>
                    <?php endif; ?>
                    <?php $i++; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
</main>

<footer id="footer" class="footer">
	<div class="footer__container _container">
		<div class="footer__body">
			<div class="footer__left-side left-side">
				<a href="<?php echo esc_url(home_url('/')); ?>" class="left-side__logo logo">
					<?php if (!empty(mvt_get_option('logo'))) : ?>
						<img src="<?php echo esc_url(mvt_get_option('logo')); ?>" alt="<?php bloginfo('name') ?>" class="logo__img">
					<?php else : ?>
						<img src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/img/logo.png" alt="<?php bloginfo('name') ?>" class="logo__img">
					<?php endif; ?>
				</a>
				<div class="left-side__copyright">
					&copy; <?php echo date("Y") ?> <?php esc_html_e('created by', 'cinemaxl') ?> <a href="https://mv-theme.pro/"><?php esc_html_e('MVTHEME Agency', 'cinemaxl') ?></a>
				</div>
			</div>
			<div class="footer__right-side right-side">
				<?php if (has_nav_menu('footer_menu')) : ?>
					<nav class="right-side__menu menu">
						<?php wp_nav_menu(array(
							'theme_location'  => 'footer_menu',
							'container'       => 'ul',
							'menu_class'      => 'menu__list',
							'link_before'     => '<span>',
							'link_after'      => '</span>',
						)); ?>
					</nav>
				<?php endif; ?>
				<a href="#header" class="right-side__scroll-up go_to">
					<i class="icon-arrow-up"></i>
				</a>
			</div>
		</div>
	</div>
</footer><!-- footer -->
</div><!-- #page -->

<!-- MODAL WINDOW -->
<div class="popup popup_js-form">
	<div class="popup__overlay">
		<div class="popup__body" onclick="event.stopPropagation();">
			<div class="popup__close"></div>
			<div class="js-form">
			</div>
		</div>
	</div>
</div>
<!-- END MODAL WINDOW -->

<?php wp_footer(); ?>

</body>

</html>